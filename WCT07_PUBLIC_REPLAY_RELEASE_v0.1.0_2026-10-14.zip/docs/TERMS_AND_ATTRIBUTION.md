# Publication terms check and source attribution

Checked 2026-10-13. Practical publication assessment, not a legal opinion or guarantee of copyright protection. Outputs came through Kaggle; direct-provider terms are supporting context, not proof that a user is the direct contracting API customer.

- OpenAI Services Agreement, effective 2026-01-01, section 4.1: customer output ownership subject to applicable law. https://openai.com/policies/services-agreement/
- Anthropic Commercial Terms, effective 2025-06-17, section B: customer output ownership subject to applicable law. https://www.anthropic.com/legal/commercial-terms
- Gemini API Additional Terms, generated-content section: Google does not claim ownership; user remains responsible for use. https://ai.google.dev/gemini-api/terms
- Kaggle Terms, sections 5/9: respect third-party rights; ownership of user submissions is not changed by the licenses granted to Kaggle. https://www.kaggle.com/terms

No general output-publication prohibition was identified in these sources. This is not blanket clearance for third-party material, confidential content, attribution omissions, or competing-model training. Kaggle-specific additional/accepted model-access terms, if any, have not been established by these generic terms alone.

Source: Allen Institute for AI, allenai/WildChat-1M. https://huggingface.co/datasets/allenai/WildChat-1M
The source dataset card identifies ODC-BY. https://opendatacommons.org/licenses/by/1-0/
Source identifiers and the later verified matching snapshot are recorded in source_identity.json; that snapshot is not asserted to be the original collection revision.

Public fixtures are explicitly name-substituted derivatives of retained fixtures, not the original conversation. Numerical election data is unchanged. The source conversation and full provider responses are withheld. Generated programs retain their bytes. Original private research files are preserved.

This candidate does not assert a blanket MIT license over generated programs or external source data. Project license scope is now explicit in LICENSE_SCOPE.md. These notices do not amend platform-specific terms or certify third-party rights. New replay utilities are project-authored; evaluator/program copyright eligibility and third-party rights are not guaranteed by provider ownership clauses.
