#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CANDIDATES 50   /* nombre maximum de candidats          */
#define MAX_NAME       100  /* longueur maximale d'un nom           */
#define MAX_VOTES      1000 /* nombre maximum de bulletins          */

int main(void)
{
    FILE *fileIn, *fileOut;

    char candidateNames[MAX_CANDIDATES][MAX_NAME];
    int  candidateVotes[MAX_CANDIDATES] = {0};
    int  invalidList[MAX_VOTES];                 /* pour garder les votes invalides */

    int numOfCandidates = 0;
    int totalVotes = 0, validVotes = 0, invalidVotes = 0;
    int maxVotes = 0, maxNameWidth = 0, width;
    int i, vote, len;

    /* ---------- Ouverture du fichier d'entree ---------- */
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    /* ---------- Lecture des noms des candidats ---------- */
    /* On lit ligne par ligne tant que la ligne n'est pas une ligne de chiffres */
    while (numOfCandidates < MAX_CANDIDATES &&
           fscanf(fileIn, " %99[^\n]", candidateNames[numOfCandidates]) == 1)
    {
        /* Si la ligne commence par un chiffre, ce sont les votes : on s'arrete */
        if (candidateNames[numOfCandidates][0] >= '0' &&
            candidateNames[numOfCandidates][0] <= '9')
        {
            /* on remet la ligne dans le flux : plus simple -> on la traite ici */
            char *token = strtok(candidateNames[numOfCandidates], " \t\r\n");
            while (token != NULL) {
                vote = atoi(token);
                totalVotes++;
                if (vote >= 1 && vote <= numOfCandidates) {
                    validVotes++;
                    candidateVotes[vote - 1]++;
                } else {
                    if (invalidVotes < MAX_VOTES)
                        invalidList[invalidVotes] = vote;
                    invalidVotes++;
                }
                token = strtok(NULL, " \t\r\n");
            }
            break;  /* la premiere ligne de votes a ete traitee */
        }

        /* Suppression d'un eventuel '\r' (fichiers Windows) */
        len = (int)strlen(candidateNames[numOfCandidates]);
        if (len > 0 && candidateNames[numOfCandidates][len - 1] == '\r')
            candidateNames[numOfCandidates][len - 1] = '\0';

        numOfCandidates++;
    }

    /* ---------- Lecture des votes restants (s'il y en a sur d'autres lignes) ---------- */
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            validVotes++;
            candidateVotes[vote - 1]++;
        } else {
            if (invalidVotes < MAX_VOTES)
                invalidList[invalidVotes] = vote;
            invalidVotes++;
        }
    }

    fclose(fileIn);

    /* ---------- Recherche du score maximal ---------- */
    for (i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] > maxVotes)
            maxVotes = candidateVotes[i];
    }

    /* ---------- Largeur de la colonne "Candidat" ---------- */
    maxNameWidth = (int)strlen("Candidat");
    for (i = 0; i < numOfCandidates; i++) {
        len = (int)strlen(candidateNames[i]);
        if (len > maxNameWidth)
            maxNameWidth = len;
    }
    width = maxNameWidth + 2;   /* 2 espaces de separation */

    /* ---------- Ouverture du fichier de sortie ---------- */
    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    /* ---------- Ecriture des resultats ---------- */
    for (i = 0; i < invalidVotes && i < MAX_VOTES; i++)
        fprintf(fileOut, "Vote invalide : %d\n", invalidList[i]);

    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", validVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidVotes);
    fprintf(fileOut, "\n");

    fprintf(fileOut, "%-*s%s\n", width, "Candidat", "Score");
    for (i = 0; i < numOfCandidates; i++)
        fprintf(fileOut, "%-*s%5d\n", width, candidateNames[i], candidateVotes[i]);

    fprintf(fileOut, "\nLes gagnants:\n");
    for (i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] == maxVotes)
            fprintf(fileOut, "%s\n", candidateNames[i]);
    }

    fclose(fileOut);

    printf("Les resultats ont ete ecrits dans resultats.txt\n");
    return EXIT_SUCCESS;
}
