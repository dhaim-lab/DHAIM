#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM_LEN 100

int main() {
    FILE *fin = fopen("votes.txt", "r");
    if (fin == NULL) {
        printf("Erreur : Impossible d'ouvrir le fichier votes.txt\n");
        return 1;
    }

    FILE *fout = fopen("resultats.txt", "w");
    if (fout == NULL) {
        printf("Erreur : Impossible de creer le fichier resultats.txt\n");
        fclose(fin);
        return 1;
    }

    char noms[MAX_CANDIDATS][MAX_NOM_LEN];
    int scores[MAX_CANDIDATS] = {0};
    int nb_candidats = 0;

    char ligne[1024];

    // 1. Lecture des noms des candidats
    while (fgets(ligne, sizeof(ligne), fin)) {
        // Supprimer le saut de ligne à la fin (\r et \n)
        ligne[strcspn(ligne, "\r\n")] = '\0';

        // Ignorer les lignes vides
        if (strlen(ligne) == 0) continue;

        // Ignorer les espaces de début
        int i = 0;
        while (isspace(ligne[i])) i++;

        // Si la ligne commence par un chiffre, c'est la ligne des votes
        if (isdigit(ligne[i])) {
            break;
        }

        // Sinon, c'est le nom d'un candidat
        strcpy(noms[nb_candidats], ligne);
        nb_candidats++;
    }

    int total_votes = 0;
    int votes_valides = 0;
    int votes_annules = 0;

    // 2. Traitement des votes sur la première ligne de votes détectée
    char *token = strtok(ligne, " \t\r\n");
    while (token != NULL) {
        int vote = atoi(token);
        total_votes++;

        if (vote >= 1 && vote <= nb_candidats) {
            scores[vote - 1]++;
            votes_valides++;
        } else {
            votes_annules++;
            fprintf(fout, "Vote invalide : %d\n", vote);
        }
        token = strtok(NULL, " \t\r\n");
    }

    // Traitement d'éventuels votes supplémentaires sur les lignes suivantes
    int vote;
    while (fscanf(fin, "%d", &vote) == 1) {
        total_votes++;
        if (vote >= 1 && vote <= nb_candidats) {
            scores[vote - 1]++;
            votes_valides++;
        } else {
            votes_annules++;
            fprintf(fout, "Vote invalide : %d\n", vote);
        }
    }

    // 3. Écriture des statistiques globales
    fprintf(fout, "Nombre d'électeurs : %d\n", total_votes);
    fprintf(fout, "Nombre de votes valides : %d\n", votes_valides);
    fprintf(fout, "Nombre de votes annules : %d\n", votes_annules);

    // 4. Écriture des scores par candidat
    fprintf(fout, "Candidat score\n");
    int max_score = 0;
    for (int i = 0; i < nb_candidats; i++) {
        fprintf(fout, "%s %d\n", noms[i], scores[i]);
        if (scores[i] > max_score) {
            max_score = scores[i];
        }
    }

    // 5. Affichage du/des gagnant(s)
    fprintf(fout, "Les gagnants:\n");
    for (int i = 0; i < nb_candidats; i++) {
        if (scores[i] == max_score) {
            fprintf(fout, "%s\n", noms[i]);
        }
    }

    // Fermeture des fichiers
    fclose(fin);
    fclose(fout);

    printf("Traitement termine avec succes. Les resultats sont dans 'resultats.txt'.\n");
    return 0;
}
