#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 50     /* nombre maximum de candidats          */
#define MAX_NOM       100    /* longueur maximale d'un nom           */
#define MAX_VOTES     1000   /* nombre maximum de bulletins          */

int main(void)
{
    FILE *entree, *sortie;

    char nomsCandidats[MAX_CANDIDATS][MAX_NOM];
    int  scores[MAX_CANDIDATS] = {0};
    int  votes[MAX_VOTES];
    int  votesInvalides[MAX_VOTES];

    int nbCandidats = 0;
    int nbVotes = 0;
    int nbInvalides = 0;
    int nbValides = 0;
    int meilleurScore = 0;
    int largeurNom = 8;              /* longueur de "Candidat" */

    char ligne[1024];
    int  i, v, pos, lu;
    int  lectureVotes = 0;           /* 0 : on lit les noms, 1 : on lit les votes */

    /* ---------- 1. Ouverture du fichier d'entree ---------- */
    entree = fopen("votes.txt", "r");
    if (entree == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    /* ---------- 2. Lecture du fichier ---------- */
    while (fgets(ligne, sizeof(ligne), entree) != NULL) {

        /* suppression du '\n' et du '\r' eventuels */
        ligne[strcspn(ligne, "\r\n")] = '\0';

        /* on ignore les lignes vides */
        if (ligne[0] == '\0')
            continue;

        /* la premiere ligne commencant par un chiffre marque le debut des votes */
        if (!lectureVotes && isdigit((unsigned char)ligne[0]))
            lectureVotes = 1;

        if (!lectureVotes) {
            /* ----- lecture d'un nom de candidat ----- */
            if (nbCandidats < MAX_CANDIDATS) {
                strncpy(nomsCandidats[nbCandidats], ligne, MAX_NOM - 1);
                nomsCandidats[nbCandidats][MAX_NOM - 1] = '\0';

                if ((int)strlen(nomsCandidats[nbCandidats]) > largeurNom)
                    largeurNom = (int)strlen(nomsCandidats[nbCandidats]);

                nbCandidats++;
            }
        } else {
            /* ----- lecture des votes de la ligne ----- */
            pos = 0;
            while (sscanf(ligne + pos, "%d%n", &v, &lu) == 1) {
                pos += lu;
                if (nbVotes < MAX_VOTES)
                    votes[nbVotes++] = v;
            }
        }
    }
    fclose(entree);

    /* ---------- 3. Depouillement ---------- */
    for (i = 0; i < nbVotes; i++) {
        if (votes[i] >= 1 && votes[i] <= nbCandidats) {
            scores[votes[i] - 1]++;
            nbValides++;
        } else {
            votesInvalides[nbInvalides++] = votes[i];
        }
    }

    /* recherche du meilleur score */
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] > meilleurScore)
            meilleurScore = scores[i];

    /* ---------- 4. Ecriture des resultats ---------- */
    sortie = fopen("resultats.txt", "w");
    if (sortie == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        return EXIT_FAILURE;
    }

    /* les bulletins nuls */
    for (i = 0; i < nbInvalides; i++)
        fprintf(sortie, "Vote invalide : %d\n", votesInvalides[i]);

    /* les statistiques */
    fprintf(sortie, "Nombre d'electeurs : %d\n", nbVotes);
    fprintf(sortie, "Nombre de votes valides : %d\n", nbValides);
    fprintf(sortie, "Nombre de votes annules : %d\n", nbInvalides);

    /* le tableau des scores, aligne */
    fprintf(sortie, "%-*s  %s\n", largeurNom, "Candidat", "score");
    for (i = 0; i < nbCandidats; i++)
        fprintf(sortie, "%-*s  %5d\n", largeurNom, nomsCandidats[i], scores[i]);

    /* le(s) gagnant(s) */
    fprintf(sortie, "Les gagnants:\n");
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] == meilleurScore)
            fprintf(sortie, "%s\n", nomsCandidats[i]);

    fclose(sortie);

    printf("Depouillement termine. Les resultats sont dans resultats.txt\n");
    return EXIT_SUCCESS;
}
