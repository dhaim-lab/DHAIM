/* ============================================================
   Depouillement d'une election
   Entree  : votes.txt   (les noms des candidats puis les votes)
   Sortie  : resultats.txt
   ============================================================ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100   /* nombre maximum de candidats          */
#define MAX_NOM       101   /* longueur maximale d'un nom           */
#define MAX_LIGNE     1024  /* longueur maximale d'une ligne du fichier */

int main(void)
{
    FILE *fin, *fout;
    char  ligne[MAX_LIGNE];
    char  noms[MAX_CANDIDATS][MAX_NOM];
    int   scores[MAX_CANDIDATS] = {0};

    int nbCandidats = 0;
    int nbElecteurs = 0, nbValides = 0, nbAnnules = 0;
    int i, v, max;

    /* ---------- ouverture des fichiers ---------- */
    fin = fopen("votes.txt", "r");
    if (fin == NULL) {
        printf("Erreur : impossible d'ouvrir votes.txt\n");
        return 1;
    }

    fout = fopen("resultats.txt", "w");
    if (fout == NULL) {
        printf("Erreur : impossible de creer resultats.txt\n");
        fclose(fin);
        return 1;
    }

    /* ---------- lecture du fichier ----------
       Une ligne qui commence par une lettre  -> nom d'un candidat
       Une ligne qui commence par un chiffre  -> liste des votes     */
    while (fgets(ligne, sizeof(ligne), fin) != NULL)
    {
        char *p = ligne;

        ligne[strcspn(ligne, "\r\n")] = '\0';        /* enlever le '\n' */
        while (isspace((unsigned char)*p)) p++;      /* sauter les blancs */

        if (*p == '\0')                              /* ligne vide */
            continue;

        if (isdigit((unsigned char)*p))              /* ---- les votes ---- */
        {
            int lus;
            while (sscanf(p, "%d%n", &v, &lus) == 1)
            {
                p += lus;
                nbElecteurs++;

                if (v >= 1 && v <= nbCandidats) {    /* vote valide   */
                    scores[v - 1]++;
                    nbValides++;
                } else {                             /* vote annule   */
                    nbAnnules++;
                    fprintf(fout, "Vote invalide : %d\n", v);
                }
            }
        }
        else                                         /* ---- un nom ---- */
        {
            if (nbCandidats < MAX_CANDIDATS) {
                strncpy(noms[nbCandidats], p, MAX_NOM - 1);
                noms[nbCandidats][MAX_NOM - 1] = '\0';
                nbCandidats++;
            }
        }
    }

    /* ---------- statistiques ---------- */
    fprintf(fout, "Nombre d'electeurs : %d\n", nbElecteurs);
    fprintf(fout, "Nombre de votes valides : %d\n", nbValides);
    fprintf(fout, "Nombre de votes annules : %d\n\n", nbAnnules);

    /* ---------- tableau des resultats ---------- */
    fprintf(fout, "%-20s %s\n", "Candidat", "score");
    for (i = 0; i < nbCandidats; i++)
        fprintf(fout, "%-20s %d\n", noms[i], scores[i]);

    /* ---------- recherche du (des) gagnant(s) ---------- */
    max = 0;
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] > max)
            max = scores[i];

    fprintf(fout, "\nLes gagnants:\n");
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] == max)
            fprintf(fout, "%s\n", noms[i]);

    fclose(fin);
    fclose(fout);

    printf("Depouillement termine : voir le fichier resultats.txt\n");
    return 0;
}
