#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100   /* nombre maximum de candidats          */
#define MAX_NOM       101   /* longueur maximale d'un nom           */
#define MAX_LIGNE    4096   /* longueur maximale d'une ligne du fichier */

/* Enleve les espaces en debut et en fin de chaine */
static char *nettoyer(char *s)
{
    char *debut = s;
    char *fin;

    while (*debut && isspace((unsigned char)*debut))
        debut++;

    if (*debut == '\0')
        return debut;

    fin = debut + strlen(debut) - 1;
    while (fin > debut && isspace((unsigned char)*fin))
        *fin-- = '\0';

    return debut;
}

int main(void)
{
    FILE *entree, *sortie;
    char  noms[MAX_CANDIDATS][MAX_NOM];
    int   scores[MAX_CANDIDATS] = {0};
    int   nbCandidats = 0;
    int   totalVotes = 0, votesValides = 0, votesAnnules = 0;
    int   maxScore = 0;
    char  ligne[MAX_LIGNE];
    int   zoneVotes = 0;          /* 0 : on lit les noms, 1 : on lit les votes */
    int   i;

    /* --- Ouverture des fichiers ------------------------------------ */
    entree = fopen("votes.txt", "r");
    if (entree == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier votes.txt\n");
        return 1;
    }

    sortie = fopen("resultats.txt", "w");
    if (sortie == NULL) {
        printf("Erreur : impossible de creer le fichier resultats.txt\n");
        fclose(entree);
        return 1;
    }

    /* --- Lecture du fichier ---------------------------------------- */
    while (fgets(ligne, sizeof(ligne), entree) != NULL) {

        char *p = nettoyer(ligne);

        if (*p == '\0')                 /* ligne vide : on l'ignore */
            continue;

        /* Tant qu'on n'a pas rencontre de chiffre, ce sont des noms */
        if (!zoneVotes && !isdigit((unsigned char)*p) && *p != '-') {

            if (nbCandidats < MAX_CANDIDATS) {
                strncpy(noms[nbCandidats], p, MAX_NOM - 1);
                noms[nbCandidats][MAX_NOM - 1] = '\0';
                scores[nbCandidats] = 0;
                nbCandidats++;
            }
        }
        else {   /* --- partie des votes --- */
            int vote, lus;

            zoneVotes = 1;

            while (sscanf(p, "%d%n", &vote, &lus) == 1) {
                p += lus;
                totalVotes++;

                if (vote >= 1 && vote <= nbCandidats) {
                    scores[vote - 1]++;
                    votesValides++;
                } else {
                    fprintf(sortie, "Vote invalide : %d\n", vote);
                    votesAnnules++;
                }
            }
        }
    }
    fclose(entree);

    /* --- Statistiques globales ------------------------------------- */
    fprintf(sortie, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(sortie, "Nombre de votes valides : %d\n", votesValides);
    fprintf(sortie, "Nombre de votes annules : %d\n\n", votesAnnules);

    /* --- Resultats par candidat ------------------------------------ */
    fprintf(sortie, "%-20s %s\n", "Candidat", "score");
    for (i = 0; i < nbCandidats; i++) {
        fprintf(sortie, "%-20s %d\n", noms[i], scores[i]);
        if (scores[i] > maxScore)
            maxScore = scores[i];
    }

    /* --- Gagnant(s) ------------------------------------------------ */
    fprintf(sortie, "\nLes gagnants:\n");
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] == maxScore)
            fprintf(sortie, "%s\n", noms[i]);

    fclose(sortie);

    printf("Les resultats ont ete ecrits dans resultats.txt\n");
    return 0;
}
