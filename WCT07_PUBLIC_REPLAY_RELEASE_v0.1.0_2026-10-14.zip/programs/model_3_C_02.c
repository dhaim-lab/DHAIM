#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM_LEN 100
#define BUFFER_SIZE 2048

int main() {
    FILE *f_in = fopen("votes.txt", "r");
    FILE *f_out = fopen("resultats.txt", "w");

    if (f_in == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier votes.txt\n");
        return 1;
    }
    if (f_out == NULL) {
        printf("Erreur : impossible de creer le fichier resultats.txt\n");
        fclose(f_in);
        return 1;
    }

    char candidats[MAX_CANDIDATS][MAX_NOM_LEN];
    int scores[MAX_CANDIDATS] = {0};
    int nb_candidats = 0;

    int total_votes = 0;
    int votes_valides = 0;
    int votes_annules = 0;

    char buffer[BUFFER_SIZE];

    // 1. Lecture des candidats et bascule vers les votes
    while (fgets(buffer, sizeof(buffer), f_in)) {
        // Supprimer le saut de ligne (\n ou \r\n)
        buffer[strcspn(buffer, "\r\n")] = '\0';

        // Ignorer les lignes vides éventuelles
        if (strlen(buffer) == 0) {
            continue;
        }

        // Si la ligne commence par un chiffre, il s'agit de la ligne des votes
        if (isdigit((unsigned char)buffer[0])) {
            // Traiter cette ligne de votes avec strtok
            char *token = strtok(buffer, " \t");
            while (token != NULL) {
                int vote = atoi(token);
                total_votes++;

                if (vote >= 1 && vote <= nb_candidats) {
                    scores[vote - 1]++;
                    votes_valides++;
                } else {
                    votes_annules++;
                    fprintf(f_out, "Vote invalide : %d\n", vote);
                }
                token = strtok(NULL, " \t");
            }
            break; // On quitte la boucle des noms
        } else {
            // C'est un nom de candidat
            if (nb_candidats < MAX_CANDIDATS) {
                strncpy(candidats[nb_candidats], buffer, MAX_NOM_LEN - 1);
                candidats[nb_candidats][MAX_NOM_LEN - 1] = '\0';
                nb_candidats++;
            }
        }
    }

    // 2. Lecture du reste des votes (au cas où ils continuent sur d'autres lignes)
    int vote;
    while (fscanf(f_in, "%d", &vote) == 1) {
        total_votes++;
        if (vote >= 1 && vote <= nb_candidats) {
            scores[vote - 1]++;
            votes_valides++;
        } else {
            votes_annules++;
            fprintf(f_out, "Vote invalide : %d\n", vote);
        }
    }

    // 3. Écriture du résumé des statistiques
    fprintf(f_out, "Nombre d'électeurs : %d\n", total_votes);
    fprintf(f_out, "Nombre de votes valides : %d\n", votes_valides);
    fprintf(f_out, "Nombre de votes annules : %d\n", votes_annules);

    // 4. Écriture des scores par candidat et recherche du score maximum
    fprintf(f_out, "Candidat score\n");
    int max_score = 0;
    for (int i = 0; i < nb_candidats; i++) {
        fprintf(f_out, "%s %d\n", candidats[i], scores[i]);
        if (scores[i] > max_score) {
            max_score = scores[i];
        }
    }

    // 5. Affichage du/des gagnant(s)
    fprintf(f_out, "Les gagnants:\n");
    for (int i = 0; i < nb_candidats; i++) {
        if (scores[i] == max_score) {
            fprintf(f_out, "%s\n", candidats[i]);
        }
    }

    // Fermeture des fichiers
    fclose(f_in);
    fclose(f_out);

    printf("Traitement termine avec succes. Consultez 'resultats.txt'.\n");
    return 0;
}
