#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define TAILLE_NOM    256
#define TAILLE_LIGNE  1024

/* Vérifie si une ligne contient uniquement des nombres entiers. */
int est_ligne_de_votes(const char *ligne)
{
    const char *p = ligne;
    char *fin;
    int nombre_trouve = 0;

    while (*p != '\0') {
        while (isspace((unsigned char)*p)) {
            p++;
        }

        if (*p == '\0') {
            break;
        }

        strtol(p, &fin, 10);

        if (p == fin) {
            return 0; /* Un élément n'est pas un entier. */
        }

        nombre_trouve = 1;
        p = fin;
    }

    return nombre_trouve;
}

/* Supprime le retour à la ligne placé à la fin d'une chaîne. */
void supprimer_fin_ligne(char *chaine)
{
    chaine[strcspn(chaine, "\r\n")] = '\0';
}

int main(void)
{
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[MAX_CANDIDATS][TAILLE_NOM];
    int scores[MAX_CANDIDATS] = {0};

    char ligne[TAILLE_LIGNE];
    int nombreCandidats = 0;
    int lectureVotes = 0;

    int nombreElecteurs = 0;
    int votesValides = 0;
    int votesAnnules = 0;

    fichierVotes = fopen("votes.txt", "r");

    if (fichierVotes == NULL) {
        fprintf(stderr, "Erreur : impossible d'ouvrir votes.txt\n");
        return EXIT_FAILURE;
    }

    fichierResultats = fopen("resultats.txt", "w");

    if (fichierResultats == NULL) {
        fprintf(stderr, "Erreur : impossible de créer resultats.txt\n");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    while (fgets(ligne, sizeof(ligne), fichierVotes) != NULL) {
        supprimer_fin_ligne(ligne);

        /* Ignorer les lignes vides. */
        if (ligne[0] == '\0') {
            continue;
        }

        if (!lectureVotes && !est_ligne_de_votes(ligne)) {
            if (nombreCandidats >= MAX_CANDIDATS) {
                fprintf(stderr, "Erreur : trop de candidats.\n");
                fclose(fichierVotes);
                fclose(fichierResultats);
                return EXIT_FAILURE;
            }

            strncpy(candidats[nombreCandidats],
                    ligne,
                    TAILLE_NOM - 1);

            candidats[nombreCandidats][TAILLE_NOM - 1] = '\0';
            nombreCandidats++;
        } else {
            char *p = ligne;
            char *fin;

            lectureVotes = 1;

            while (*p != '\0') {
                long vote;

                while (isspace((unsigned char)*p)) {
                    p++;
                }

                if (*p == '\0') {
                    break;
                }

                vote = strtol(p, &fin, 10);

                if (p == fin) {
                    break;
                }

                nombreElecteurs++;

                if (vote >= 1 && vote <= nombreCandidats) {
                    scores[vote - 1]++;
                    votesValides++;
                } else {
                    fprintf(fichierResultats,
                            "Vote invalide : %ld\n",
                            vote);
                    votesAnnules++;
                }

                p = fin;
            }
        }
    }

    fprintf(fichierResultats,
            "Nombre d'électeurs : %d\n",
            nombreElecteurs);

    fprintf(fichierResultats,
            "Nombre de votes valides : %d\n",
            votesValides);

    fprintf(fichierResultats,
            "Nombre de votes annules : %d\n",
            votesAnnules);

    fprintf(fichierResultats, "Candidat score\n");

    for (int i = 0; i < nombreCandidats; i++) {
        fprintf(fichierResultats,
                "%s %d\n",
                candidats[i],
                scores[i]);
    }

    /* Recherche du score maximal. */
    int scoreMaximum = 0;

    for (int i = 0; i < nombreCandidats; i++) {
        if (scores[i] > scoreMaximum) {
            scoreMaximum = scores[i];
        }
    }

    fprintf(fichierResultats, "Les gagnants:\n");

    for (int i = 0; i < nombreCandidats; i++) {
        if (scores[i] == scoreMaximum) {
            fprintf(fichierResultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichierVotes);
    fclose(fichierResultats);

    return EXIT_SUCCESS;
}
