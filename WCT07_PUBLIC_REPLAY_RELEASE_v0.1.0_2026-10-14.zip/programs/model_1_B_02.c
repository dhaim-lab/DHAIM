#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM 100
#define MAX_LIGNE 4096

/*
 * Traite une ligne contenant des votes.
 */
void traiterVotes(const char *ligne,
                  int scores[],
                  int nombreCandidats,
                  int *nombreElecteurs,
                  int *votesValides,
                  int *votesAnnules,
                  FILE *fichierResultats)
{
    const char *position = ligne;
    char *fin;
    long vote;

    while (*position != '\0') {
        /* Ignorer les espaces */
        while (isspace((unsigned char)*position)) {
            position++;
        }

        if (*position == '\0') {
            break;
        }

        vote = strtol(position, &fin, 10);

        /* Si aucun nombre n'a été trouvé */
        if (position == fin) {
            position++;
            continue;
        }

        (*nombreElecteurs)++;

        if (vote >= 1 && vote <= nombreCandidats) {
            scores[vote - 1]++;
            (*votesValides)++;
        } else {
            fprintf(fichierResultats, "Vote invalide : %ld\n", vote);
            (*votesAnnules)++;
        }

        position = fin;
    }
}

int main(void)
{
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[MAX_CANDIDATS][MAX_NOM];
    int scores[MAX_CANDIDATS] = {0};

    char ligne[MAX_LIGNE];
    char *position;
    char *fin;

    int nombreCandidats = 0;
    int nombreElecteurs = 0;
    int votesValides = 0;
    int votesAnnules = 0;

    int largeurMax = (int)strlen("Candidat");
    int scoreMaximum = 0;
    int i;

    fichierVotes = fopen("votes.txt", "r");

    if (fichierVotes == NULL) {
        perror("Impossible d'ouvrir votes.txt");
        return EXIT_FAILURE;
    }

    fichierResultats = fopen("resultats.txt", "w");

    if (fichierResultats == NULL) {
        perror("Impossible d'ouvrir resultats.txt");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    /*
     * Lecture du fichier ligne par ligne.
     * Une ligne commençant par un nombre indique le début des votes.
     */
    while (fgets(ligne, sizeof(ligne), fichierVotes) != NULL) {
        /* Supprimer \n et \r à la fin de la ligne */
        ligne[strcspn(ligne, "\r\n")] = '\0';

        position = ligne;

        /* Ignorer les espaces au début */
        while (isspace((unsigned char)*position)) {
            position++;
        }

        /* Ignorer une éventuelle ligne vide */
        if (*position == '\0') {
            continue;
        }

        /*
         * Vérifier si la ligne commence par un nombre.
         */
        strtol(position, &fin, 10);

        if (fin != position) {
            /*
             * La première ligne de votes a été trouvée.
             */
            traiterVotes(
                position,
                scores,
                nombreCandidats,
                &nombreElecteurs,
                &votesValides,
                &votesAnnules,
                fichierResultats
            );

            break;
        }

        /*
         * Sinon, la ligne contient le nom d'un candidat.
         */
        if (nombreCandidats < MAX_CANDIDATS) {
            strncpy(
                candidats[nombreCandidats],
                position,
                MAX_NOM - 1
            );

            candidats[nombreCandidats][MAX_NOM - 1] = '\0';

            int longueur =
                (int)strlen(candidats[nombreCandidats]);

            if (longueur > largeurMax) {
                largeurMax = longueur;
            }

            nombreCandidats++;
        } else {
            fprintf(stderr, "Nombre maximal de candidats dépassé.\n");
            fclose(fichierVotes);
            fclose(fichierResultats);
            return EXIT_FAILURE;
        }
    }

    /*
     * Lecture des éventuelles autres lignes contenant des votes.
     */
    while (fgets(ligne, sizeof(ligne), fichierVotes) != NULL) {
        traiterVotes(
            ligne,
            scores,
            nombreCandidats,
            &nombreElecteurs,
            &votesValides,
            &votesAnnules,
            fichierResultats
        );
    }

    /*
     * Recherche du score maximal.
     */
    for (i = 0; i < nombreCandidats; i++) {
        if (scores[i] > scoreMaximum) {
            scoreMaximum = scores[i];
        }
    }

    /*
     * Écriture des statistiques générales.
     */
    fprintf(
        fichierResultats,
        "Nombre d'électeurs : %d\n",
        nombreElecteurs
    );

    fprintf(
        fichierResultats,
        "Nombre de votes valides : %d\n",
        votesValides
    );

    fprintf(
        fichierResultats,
        "Nombre de votes annules : %d\n",
        votesAnnules
    );

    /*
     * Le signe - aligne les noms à gauche.
     * largeurMax garantit que tous les scores sont dans la même colonne.
     */
    fprintf(
        fichierResultats,
        "%-*s  %s\n",
        largeurMax,
        "Candidat",
        "score"
    );

    for (i = 0; i < nombreCandidats; i++) {
        fprintf(
            fichierResultats,
            "%-*s  %d\n",
            largeurMax,
            candidats[i],
            scores[i]
        );
    }

    /*
     * Affichage du ou des gagnants.
     */
    fprintf(fichierResultats, "Les gagnants:\n");

    for (i = 0; i < nombreCandidats; i++) {
        if (scores[i] == scoreMaximum) {
            fprintf(
                fichierResultats,
                "%s\n",
                candidats[i]
            );
        }
    }

    fclose(fichierVotes);
    fclose(fichierResultats);

    printf("Les résultats ont été enregistrés dans resultats.txt\n");

    return EXIT_SUCCESS;
}
