#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATES 50
#define MAX_NAME_LEN 100
#define MAX_INVALID_VOTES 1000

int main() {
    FILE *fileIn, *fileOut;
    char candidates[MAX_CANDIDATES][MAX_NAME_LEN];
    int scores[MAX_CANDIDATES] = {0};
    int invalidList[MAX_INVALID_VOTES];
    
    int candidateCount = 0;
    int invalidCount = 0;
    int totalVotes = 0;
    int validVotes = 0;
    int maxScore = 0;
    
    char line[512];

    // 1. Ouverture du fichier source
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    // 2. Lecture des noms et détection de la ligne de votes
    while (fgets(line, sizeof(line), fileIn) != NULL) {
        // Nettoyer les sauts de ligne \r et \n
        line[strcspn(line, "\r\n")] = '\0';

        // Ignorer les lignes vides
        if (strlen(line) == 0) continue;

        // Trouver le premier caractère non vide
        char *ptr = line;
        while (isspace((unsigned char)*ptr)) ptr++;

        // Si la ligne commence par un chiffre, les noms sont finis, on traite les votes
        if (isdigit((unsigned char)*ptr)) {
            int vote;
            int offset;
            while (sscanf(ptr, "%d%n", &vote, &offset) == 1) {
                totalVotes++;
                if (vote >= 1 && vote <= candidateCount) {
                    validVotes++;
                    scores[vote - 1]++;
                } else {
                    if (invalidCount < MAX_INVALID_VOTES) {
                        invalidList[invalidCount++] = vote;
                    }
                }
                ptr += offset;
            }
            break; // On a trouvé la ligne de votes, on sort de cette boucle
        } else {
            // C'est un nom de candidat
            if (candidateCount < MAX_CANDIDATES) {
                strncpy(candidates[candidateCount], ptr, MAX_NAME_LEN - 1);
                candidates[candidateCount][MAX_NAME_LEN - 1] = '\0';
                candidateCount++;
            }
        }
    }

    // 3. Lire le reste des votes s'ils continuent sur d'autres lignes
    int vote;
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= candidateCount) {
            validVotes++;
            scores[vote - 1]++;
        } else {
            if (invalidCount < MAX_INVALID_VOTES) {
                invalidList[invalidCount++] = vote;
            }
        }
    }

    fclose(fileIn);

    // 4. Calcul du score maximum
    for (int i = 0; i < candidateCount; i++) {
        if (scores[i] > maxScore) {
            maxScore = scores[i];
        }
    }

    // Trouver la longueur du plus long nom pour aligner la colonne 'score'
    int maxLen = (int)strlen("Candidat");
    for (int i = 0; i < candidateCount; i++) {
        int len = (int)strlen(candidates[i]);
        if (len > maxLen) {
            maxLen = len;
        }
    }

    // 5. Écriture des résultats dans resultats.txt
    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        return EXIT_FAILURE;
    }

    // Affichage des votes invalides
    for (int i = 0; i < invalidCount; i++) {
        fprintf(fileOut, "Vote invalide : %d\n", invalidList[i]);
    }

    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", validVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidCount);

    // En-tête aligné (ex: 2 espaces entre le nom le plus long et 'score')
    int colWidth = maxLen + 2;
    fprintf(fileOut, "%-*s score\n", colWidth, "Candidat");

    // Liste des scores alignés sous le mot "score"
    for (int i = 0; i < candidateCount; i++) {
        fprintf(fileOut, "%-*s %d\n", colWidth, candidates[i], scores[i]);
    }

    // Affichage des gagnants
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < candidateCount; i++) {
        if (scores[i] == maxScore) {
            fprintf(fileOut, "%s\n", candidates[i]);
        }
    }

    fclose(fileOut);

    return EXIT_SUCCESS;
}
