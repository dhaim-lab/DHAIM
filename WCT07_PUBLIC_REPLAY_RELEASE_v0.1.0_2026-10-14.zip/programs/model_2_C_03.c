/* ============================================================
   Programme : depouillement d'une election
   Entree    : votes.txt  (noms des candidats puis les votes)
   Sortie    : resultats.txt
   ============================================================ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CAND  100   /* nombre maximum de candidats          */
#define MAX_LEN   101   /* longueur maximum d'un nom            */
#define MAX_LIGNE 1024  /* longueur maximum d'une ligne lue     */

/* traite un bulletin : l'ajoute au bon candidat ou l'annule */
void traiterVote(int v, int nbCand, int scores[], FILE *fout,
                 int *total, int *valides, int *annules)
{
    (*total)++;
    if (v >= 1 && v <= nbCand) {       /* bulletin valide   */
        scores[v - 1]++;
        (*valides)++;
    } else {                           /* bulletin annule   */
        fprintf(fout, "Vote invalide : %d\n", v);
        (*annules)++;
    }
}

int main(void)
{
    FILE *fin, *fout;
    char noms[MAX_CAND][MAX_LEN];
    int  scores[MAX_CAND] = {0};
    char ligne[MAX_LIGNE];
    int  nbCand = 0;
    int  total = 0, valides = 0, annules = 0;
    int  v, i, max, lus;
    char *p;

    /* ---------- ouverture des fichiers ---------- */
    fin = fopen("votes.txt", "r");
    if (fin == NULL) {
        printf("Erreur : impossible d'ouvrir votes.txt\n");
        return 1;
    }
    fout = fopen("resultats.txt", "w");
    if (fout == NULL) {
        printf("Erreur : impossible de creer resultats.txt\n");
        fclose(fin);
        return 1;
    }

    /* ---------- lecture des noms des candidats ----------
       On lit ligne par ligne tant que la ligne ne commence
       pas par un chiffre (debut de la liste des votes).     */
    while (fgets(ligne, sizeof(ligne), fin) != NULL) {

        size_t len = strlen(ligne);
        while (len > 0 && (ligne[len-1] == '\n' || ligne[len-1] == '\r' ||
                           ligne[len-1] == ' '  || ligne[len-1] == '\t'))
            ligne[--len] = '\0';          /* on enleve le '\n' et les blancs */

        if (len == 0)                     /* ligne vide : on l'ignore */
            continue;

        if (isdigit((unsigned char)ligne[0]))  /* c'est la ligne des votes */
            break;

        if (nbCand < MAX_CAND) {
            strncpy(noms[nbCand], ligne, MAX_LEN - 1);
            noms[nbCand][MAX_LEN - 1] = '\0';
            scores[nbCand] = 0;
            nbCand++;
        }
    }

    /* ---------- depouillement ----------
       1) les entiers contenus dans la ligne deja lue        */
    p = ligne;
    while (sscanf(p, "%d%n", &v, &lus) == 1) {
        p += lus;
        traiterVote(v, nbCand, scores, fout, &total, &valides, &annules);
    }
    /*  2) le reste du fichier (les votes peuvent occuper
           plusieurs lignes)                                  */
    while (fscanf(fin, "%d", &v) == 1)
        traiterVote(v, nbCand, scores, fout, &total, &valides, &annules);

    fclose(fin);

    /* ---------- statistiques ---------- */
    fprintf(fout, "Nombre d'electeurs : %d\n", total);
    fprintf(fout, "Nombre de votes valides : %d\n", valides);
    fprintf(fout, "Nombre de votes annules : %d\n", annules);
    fprintf(fout, "\n");

    /* ---------- resultats par candidat ---------- */
    fprintf(fout, "%-20s %s\n", "Candidat", "score");
    for (i = 0; i < nbCand; i++)
        fprintf(fout, "%-20s %d\n", noms[i], scores[i]);

    /* ---------- recherche du (des) gagnant(s) ---------- */
    max = 0;
    for (i = 0; i < nbCand; i++)
        if (scores[i] > max)
            max = scores[i];

    fprintf(fout, "\nLes gagnants:\n");
    for (i = 0; i < nbCand; i++)
        if (scores[i] == max)
            fprintf(fout, "%s\n", noms[i]);

    fclose(fout);

    printf("Depouillement termine : voir le fichier resultats.txt\n");
    return 0;
}
