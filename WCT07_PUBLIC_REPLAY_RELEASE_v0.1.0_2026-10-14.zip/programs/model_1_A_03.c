#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NOMBRE_CANDIDATS 7
#define TAILLE_NOM 100

int main(void)
{
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[NOMBRE_CANDIDATS][TAILLE_NOM];
    int scores[NOMBRE_CANDIDATS] = {0};

    int nombreElecteurs = 0;
    int votesValides = 0;
    int votesAnnules = 0;
    int scoreMaximum = 0;
    int largeurNom = 0;
    int vote;
    int i;

    /* Ouverture du fichier contenant les candidats et les votes */
    fichierVotes = fopen("votes.txt", "r");

    if (fichierVotes == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    /* Lecture des sept candidats */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (fgets(candidats[i], TAILLE_NOM, fichierVotes) == NULL) {
            fprintf(stderr, "Erreur : candidat %d introuvable.\n", i + 1);
            fclose(fichierVotes);
            return EXIT_FAILURE;
        }

        /* Suppression de \n ou \r\n à la fin du nom */
        candidats[i][strcspn(candidats[i], "\r\n")] = '\0';

        /* Recherche de la longueur du nom le plus long */
        int longueur = (int)strlen(candidats[i]);

        if (longueur > largeurNom) {
            largeurNom = longueur;
        }
    }

    /* Ouverture du fichier de résultats */
    fichierResultats = fopen("resultats.txt", "w");

    if (fichierResultats == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    /* Lecture et comptage des votes */
    while (fscanf(fichierVotes, "%d", &vote) == 1) {
        nombreElecteurs++;

        if (vote >= 1 && vote <= NOMBRE_CANDIDATS) {
            votesValides++;
            scores[vote - 1]++;
        } else {
            votesAnnules++;
            fprintf(fichierResultats, "Vote invalide : %d\n", vote);
        }
    }

    fclose(fichierVotes);

    /* Recherche du score maximum */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (scores[i] > scoreMaximum) {
            scoreMaximum = scores[i];
        }
    }

    /* Informations générales */
    fprintf(fichierResultats,
            "Nombre d'electeurs : %d\n",
            nombreElecteurs);

    fprintf(fichierResultats,
            "Nombre de votes valides : %d\n",
            votesValides);

    fprintf(fichierResultats,
            "Nombre de votes annules : %d\n",
            votesAnnules);

    /* Tableau aligné des candidats et des scores */
    fprintf(fichierResultats, "%-*s %5s\n",
            largeurNom, "Candidat", "Score");

    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        fprintf(fichierResultats, "%-*s %5d\n",
                largeurNom,
                candidats[i],
                scores[i]);
    }

    /* Affichage du ou des gagnants */
    fprintf(fichierResultats, "Les gagnants:\n");

    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (scores[i] == scoreMaximum) {
            fprintf(fichierResultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichierResultats);

    printf("Les resultats ont ete enregistres dans resultats.txt\n");

    return EXIT_SUCCESS;
}
