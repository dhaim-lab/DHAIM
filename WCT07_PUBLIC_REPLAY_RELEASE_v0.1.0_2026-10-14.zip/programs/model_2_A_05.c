#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CANDIDATES 50
#define MAX_VOTES      1000
#define NAME_LEN       100

int main(void)
{
    FILE *fileIn, *fileOut;

    char candidateNames[MAX_CANDIDATES][NAME_LEN];
    int  candidateVotes[MAX_CANDIDATES] = {0};
    int  invalidList[MAX_VOTES];                 /* pour memoriser les votes invalides */

    int numOfCandidates = 0;
    int totalVotes = 0, invalidVotes = 0, maxVotes = 0;
    int vote, i;
    int maxNameWidth = 0, headerWidth;

    /* ---------- 1. Ouverture du fichier d'entree ---------- */
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    /* ---------- 2. Lecture des noms des candidats ---------- */
    /* Un nom par ligne : on s'arrete des qu'une ligne commence par un chiffre */
    while (numOfCandidates < MAX_CANDIDATES) {
        char buffer[NAME_LEN];
        long pos = ftell(fileIn);                /* on memorise la position */

        if (fgets(buffer, sizeof(buffer), fileIn) == NULL)
            break;

        buffer[strcspn(buffer, "\r\n")] = '\0';  /* enlever le saut de ligne */

        if (strlen(buffer) == 0)                 /* ligne vide : on l'ignore */
            continue;

        /* si la ligne commence par un chiffre -> ce sont les votes */
        if (buffer[0] >= '0' && buffer[0] <= '9') {
            fseek(fileIn, pos, SEEK_SET);        /* on revient en arriere */
            break;
        }

        strcpy(candidateNames[numOfCandidates], buffer);
        numOfCandidates++;
    }

    /* ---------- 3. Lecture et comptage des votes ---------- */
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            candidateVotes[vote - 1]++;
            if (candidateVotes[vote - 1] > maxVotes)
                maxVotes = candidateVotes[vote - 1];
        } else {
            if (invalidVotes < MAX_VOTES)
                invalidList[invalidVotes] = vote;
            invalidVotes++;
        }
    }

    fclose(fileIn);

    /* ---------- 4. Calcul de la largeur d'affichage ---------- */
    for (i = 0; i < numOfCandidates; i++) {
        int len = (int)strlen(candidateNames[i]);
        if (len > maxNameWidth)
            maxNameWidth = len;
    }
    maxNameWidth += 2;                           /* espace avant le score   */

    headerWidth = maxNameWidth;                  /* largeur pour "Candidat" */
    if (headerWidth < 9) headerWidth = 9;

    /* ---------- 5. Ecriture des resultats ---------- */
    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    for (i = 0; i < invalidVotes && i < MAX_VOTES; i++)
        fprintf(fileOut, "Vote invalide : %d\n", invalidList[i]);

    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", totalVotes - invalidVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidVotes);
    fprintf(fileOut, "\n");

    fprintf(fileOut, "%-*s%s\n", headerWidth, "Candidat", "score");
    for (i = 0; i < numOfCandidates; i++)
        fprintf(fileOut, "%-*s%5d\n", headerWidth, candidateNames[i], candidateVotes[i]);

    fprintf(fileOut, "\nLes gagnants:\n");
    for (i = 0; i < numOfCandidates; i++)
        if (candidateVotes[i] == maxVotes)
            fprintf(fileOut, "%s\n", candidateNames[i]);

    fclose(fileOut);

    printf("Traitement termine : voir le fichier resultats.txt\n");
    return EXIT_SUCCESS;
}
