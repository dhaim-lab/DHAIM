#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NOMBRE_CANDIDATS 7
#define TAILLE_NOM 100

int main(void)
{
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[NOMBRE_CANDIDATS][TAILLE_NOM];
    int scores[NOMBRE_CANDIDATS] = {0};

    int nombreElecteurs = 0;
    int votesValides = 0;
    int votesAnnules = 0;
    int scoreMaximum = 0;
    int largeurMax = 0;
    int vote;
    int i;

    /* Ouverture du fichier contenant les candidats et les votes */
    fichierVotes = fopen("votes.txt", "r");

    if (fichierVotes == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    /* Ouverture du fichier de résultats */
    fichierResultats = fopen("resultats.txt", "w");

    if (fichierResultats == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    /*
     * Lecture des 7 candidats.
     * Chaque candidat se trouve sur une ligne.
     */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (fgets(candidats[i], TAILLE_NOM, fichierVotes) == NULL) {
            fprintf(stderr, "Erreur : nombre de candidats insuffisant.\n");
            fclose(fichierVotes);
            fclose(fichierResultats);
            return EXIT_FAILURE;
        }

        /* Suppression de '\n' ou '\r\n' à la fin du nom */
        candidats[i][strcspn(candidats[i], "\r\n")] = '\0';

        /* Recherche de la longueur du nom le plus long */
        int longueur = (int)strlen(candidats[i]);

        if (longueur > largeurMax) {
            largeurMax = longueur;
        }
    }

    /*
     * Lecture et comptage des votes.
     * Les votes valides vont de 1 à 7.
     */
    while (fscanf(fichierVotes, "%d", &vote) == 1) {
        nombreElecteurs++;

        if (vote >= 1 && vote <= NOMBRE_CANDIDATS) {
            scores[vote - 1]++;
            votesValides++;
        } else {
            fprintf(fichierResultats, "Vote invalide : %d\n", vote);
            votesAnnules++;
        }
    }

    fclose(fichierVotes);

    /* Recherche du score maximum */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (scores[i] > scoreMaximum) {
            scoreMaximum = scores[i];
        }
    }

    /* Écriture des statistiques */
    fprintf(fichierResultats,
            "Nombre d'électeurs : %d\n",
            nombreElecteurs);

    fprintf(fichierResultats,
            "Nombre de votes valides : %d\n",
            votesValides);

    fprintf(fichierResultats,
            "Nombre de votes annulés : %d\n",
            votesAnnules);

    /* Affichage aligné des candidats et de leurs scores */
    fprintf(fichierResultats, "%-*s  score\n", largeurMax, "Candidat");

    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        fprintf(fichierResultats,
                "%-*s  %d\n",
                largeurMax,
                candidats[i],
                scores[i]);
    }

    /* Affichage de tous les gagnants en cas d'égalité */
    fprintf(fichierResultats, "Les gagnants:\n");

    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (scores[i] == scoreMaximum) {
            fprintf(fichierResultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichierResultats);

    printf("Les résultats ont été écrits dans resultats.txt\n");

    return EXIT_SUCCESS;
}
