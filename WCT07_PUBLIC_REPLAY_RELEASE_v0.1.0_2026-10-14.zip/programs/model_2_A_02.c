#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CANDIDATES 50   /* nombre maximal de candidats          */
#define MAX_NAME       100  /* longueur maximale d'un nom           */
#define MAX_VOTES      1000 /* nombre maximal de bulletins          */

int main(void)
{
    FILE *fileIn, *fileOut;

    char candidateNames[MAX_CANDIDATES][MAX_NAME];
    int  candidateVotes[MAX_CANDIDATES] = {0};
    int  invalidList[MAX_VOTES];                 /* valeurs des votes invalides */

    int numOfCandidates = 0;
    int totalVotes = 0, invalidVotes = 0, validVotes = 0;
    int maxVotes = 0;
    int vote, i;
    int maxNameWidth = 0;

    /* ---------- Lecture du fichier votes.txt ---------- */
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    /* Lecture des noms : une ligne qui ne commence pas par un chiffre */
    while (numOfCandidates < MAX_CANDIDATES &&
           fscanf(fileIn, " %99[^\n]", candidateNames[numOfCandidates]) == 1) {

        /* Si la ligne commence par un chiffre, c'est la ligne des votes */
        if (candidateNames[numOfCandidates][0] >= '0' &&
            candidateNames[numOfCandidates][0] <= '9') {
            /* On remet cette ligne "de côté" pour la traiter comme des votes */
            char *token = strtok(candidateNames[numOfCandidates], " \t");
            while (token != NULL) {
                vote = atoi(token);
                totalVotes++;
                if (vote >= 1 && vote <= numOfCandidates) {
                    validVotes++;
                    candidateVotes[vote - 1]++;
                } else {
                    if (invalidVotes < MAX_VOTES)
                        invalidList[invalidVotes] = vote;
                    invalidVotes++;
                }
                token = strtok(NULL, " \t");
            }
            break;  /* on sort : la suite est lue avec fscanf("%d") */
        }
        numOfCandidates++;
    }

    /* Lecture des votes restants (s'il y a plusieurs lignes de votes) */
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            validVotes++;
            candidateVotes[vote - 1]++;
        } else {
            if (invalidVotes < MAX_VOTES)
                invalidList[invalidVotes] = vote;
            invalidVotes++;
        }
    }

    fclose(fileIn);

    /* ---------- Calcul du score maximal et de la largeur d'affichage ---------- */
    for (i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] > maxVotes)
            maxVotes = candidateVotes[i];

        if ((int)strlen(candidateNames[i]) > maxNameWidth)
            maxNameWidth = (int)strlen(candidateNames[i]);
    }

    /* La colonne doit aussi pouvoir contenir le mot "Candidat" */
    if (maxNameWidth < (int)strlen("Candidat"))
        maxNameWidth = (int)strlen("Candidat");

    /* ---------- Ecriture du fichier resultats.txt ---------- */
    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    /* Liste des votes invalides */
    for (i = 0; i < invalidVotes && i < MAX_VOTES; i++)
        fprintf(fileOut, "Vote invalide : %d\n", invalidList[i]);

    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", validVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidVotes);
    fprintf(fileOut, "\n");

    /* En-tete et scores alignes */
    fprintf(fileOut, "%-*s  %s\n", maxNameWidth, "Candidat", "score");
    for (i = 0; i < numOfCandidates; i++)
        fprintf(fileOut, "%-*s  %5d\n", maxNameWidth,
                candidateNames[i], candidateVotes[i]);

    /* Gagnant(s) */
    fprintf(fileOut, "\nLes gagnants:\n");
    for (i = 0; i < numOfCandidates; i++)
        if (candidateVotes[i] == maxVotes)
            fprintf(fileOut, "%s\n", candidateNames[i]);

    fclose(fileOut);

    printf("Les resultats ont ete ecrits dans resultats.txt\n");
    return EXIT_SUCCESS;
}
