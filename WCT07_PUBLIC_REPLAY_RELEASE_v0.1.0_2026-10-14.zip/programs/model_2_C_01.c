/*  election.c
 *  Lecture du fichier "votes.txt" :
 *      - les premieres lignes contiennent les noms des candidats
 *        (candidat 1 = 1re ligne, candidat 2 = 2e ligne, ...)
 *      - la (ou les) ligne(s) suivante(s) contiennent les votes (des entiers)
 *  Ecriture des resultats dans "resultats.txt"
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CAND 100      /* nombre maximum de candidats          */
#define MAX_LEN  256      /* longueur maximale d'une ligne / nom   */

int main(void)
{
    FILE *fin, *fout;
    char noms[MAX_CAND][MAX_LEN];
    int  scores[MAX_CAND] = {0};
    int  nbCandidats = 0;
    int  total = 0, valides = 0, annules = 0;
    int  i, max;
    char ligne[MAX_LEN];

    /* ---------- ouverture des fichiers ---------- */
    fin = fopen("votes.txt", "r");
    if (fin == NULL) {
        printf("Erreur : impossible d'ouvrir votes.txt\n");
        return 1;
    }

    fout = fopen("resultats.txt", "w");
    if (fout == NULL) {
        printf("Erreur : impossible de creer resultats.txt\n");
        fclose(fin);
        return 1;
    }

    /* ---------- lecture du fichier ---------- */
    while (fgets(ligne, sizeof(ligne), fin) != NULL) {

        /* suppression du '\n', '\r' et des espaces de fin */
        size_t len = strlen(ligne);
        while (len > 0 && (ligne[len-1] == '\n' || ligne[len-1] == '\r' ||
                           ligne[len-1] == ' '  || ligne[len-1] == '\t'))
            ligne[--len] = '\0';

        if (len == 0)                 /* ligne vide : on l'ignore */
            continue;

        /* on se place sur le premier caractere non blanc */
        char *p = ligne;
        while (*p == ' ' || *p == '\t') p++;

        if (isdigit((unsigned char)*p)) {
            /* ----- c'est une ligne de votes ----- */
            char *tok = strtok(p, " \t");
            while (tok != NULL) {
                int v = atoi(tok);
                total++;
                if (v >= 1 && v <= nbCandidats) {
                    scores[v-1]++;
                    valides++;
                } else {
                    annules++;
                    fprintf(fout, "Vote invalide : %d\n", v);
                }
                tok = strtok(NULL, " \t");
            }
        } else {
            /* ----- c'est un nom de candidat ----- */
            if (nbCandidats < MAX_CAND) {
                strcpy(noms[nbCandidats], p);
                nbCandidats++;
            }
        }
    }
    fclose(fin);

    /* ---------- statistiques ---------- */
    fprintf(fout, "Nombre d'electeurs : %d\n", total);
    fprintf(fout, "Nombre de votes valides : %d\n", valides);
    fprintf(fout, "Nombre de votes annules : %d\n\n", annules);

    /* ---------- tableau des resultats ---------- */
    fprintf(fout, "%-20s %s\n", "Candidat", "score");
    for (i = 0; i < nbCandidats; i++)
        fprintf(fout, "%-20s %d\n", noms[i], scores[i]);

    /* ---------- recherche du (des) gagnant(s) ---------- */
    max = 0;
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] > max)
            max = scores[i];

    fprintf(fout, "\nLes gagnants:\n");
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] == max)
            fprintf(fout, "%s\n", noms[i]);

    fclose(fout);

    printf("Traitement termine : voir le fichier resultats.txt\n");
    return 0;
}
