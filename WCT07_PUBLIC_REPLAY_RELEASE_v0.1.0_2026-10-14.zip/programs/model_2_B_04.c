/* =====================================================================
   Programme : depouillement d'une election
   Entree    : votes.txt   -> les noms des candidats (1 par ligne)
                              puis la ligne (ou les lignes) de votes
   Sortie    : resultats.txt
   ===================================================================== */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS  50     /* nombre maximum de candidats          */
#define MAX_VOTES     1000    /* nombre maximum de bulletins          */
#define MAX_NOM        100    /* longueur maximale d'un nom           */
#define MAX_LIGNE     2048    /* longueur maximale d'une ligne lue    */

int main(void)
{
    FILE *entree, *sortie;

    char noms[MAX_CANDIDATS][MAX_NOM];   /* noms des candidats        */
    int  scores[MAX_CANDIDATS] = {0};    /* voix de chaque candidat   */
    int  invalides[MAX_VOTES];           /* liste des votes invalides */

    int nbCandidats = 0;
    int nbInvalides = 0;
    int totalVotes  = 0;
    int votesValides = 0;
    int maxVoix = 0;
    int largeur = 0;                     /* largeur de la colonne nom */

    char ligne[MAX_LIGNE];
    int i;

    /* ---------------- 1. Ouverture du fichier d'entree ------------- */
    entree = fopen("votes.txt", "r");
    if (entree == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    /* ---------------- 2. Lecture du fichier ------------------------ */
    while (fgets(ligne, sizeof(ligne), entree) != NULL) {

        /* on enleve le '\n' et l'eventuel '\r' (fichiers Windows) */
        ligne[strcspn(ligne, "\r\n")] = '\0';

        if (ligne[0] == '\0')          /* ligne vide : on ignore     */
            continue;

        if (isdigit((unsigned char)ligne[0])) {
            /* ---- c'est une ligne de votes ---- */
            char *p = ligne;
            int v, lus;

            while (sscanf(p, "%d%n", &v, &lus) == 1) {
                p += lus;                    /* on avance dans la ligne */
                totalVotes++;

                if (v >= 1 && v <= nbCandidats) {   /* vote valide */
                    votesValides++;
                    scores[v - 1]++;
                } else {                            /* vote annule */
                    if (nbInvalides < MAX_VOTES)
                        invalides[nbInvalides++] = v;
                }
            }
        } else {
            /* ---- c'est un nom de candidat ---- */
            if (nbCandidats < MAX_CANDIDATS) {
                strncpy(noms[nbCandidats], ligne, MAX_NOM - 1);
                noms[nbCandidats][MAX_NOM - 1] = '\0';
                nbCandidats++;
            }
        }
    }
    fclose(entree);

    /* ---------------- 3. Score maximum ----------------------------- */
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] > maxVoix)
            maxVoix = scores[i];

    /* ------- largeur de la colonne "Candidat" (alignement) --------- */
    largeur = (int)strlen("Candidat");
    for (i = 0; i < nbCandidats; i++) {
        int len = (int)strlen(noms[i]);
        if (len > largeur)
            largeur = len;
    }

    /* ---------------- 4. Ecriture des resultats -------------------- */
    sortie = fopen("resultats.txt", "w");
    if (sortie == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        return EXIT_FAILURE;
    }

    /* 4.a  la liste des bulletins annules */
    for (i = 0; i < nbInvalides; i++)
        fprintf(sortie, "Vote invalide : %d\n", invalides[i]);

    /* 4.b  les statistiques generales */
    fprintf(sortie, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(sortie, "Nombre de votes valides : %d\n", votesValides);
    fprintf(sortie, "Nombre de votes annules : %d\n", nbInvalides);

    /* 4.c  le tableau des scores (colonnes alignees) */
    fprintf(sortie, "\n%-*s   %s\n", largeur, "Candidat", "score");
    for (i = 0; i < nbCandidats; i++)
        fprintf(sortie, "%-*s   %5d\n", largeur, noms[i], scores[i]);

    /* 4.d  le ou les gagnants */
    fprintf(sortie, "\nLes gagnants:\n");
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] == maxVoix)
            fprintf(sortie, "%s\n", noms[i]);

    fclose(sortie);

    printf("Depouillement termine : voir le fichier resultats.txt\n");
    return EXIT_SUCCESS;
}
