#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 50
#define MAX_NOM_LEN 100
#define LIGNE_MAX 1024

int main() {
    FILE *f_in = fopen("votes.txt", "r");
    if (f_in == NULL) {
        printf("Erreur : Impossible d'ouvrir le fichier votes.txt\n");
        return 1;
    }

    FILE *f_out = fopen("resultats.txt", "w");
    if (f_out == NULL) {
        printf("Erreur : Impossible de créer le fichier resultats.txt\n");
        fclose(f_in);
        return 1;
    }

    char candidats[MAX_CANDIDATS][MAX_NOM_LEN];
    int scores[MAX_CANDIDATS] = {0};
    int nb_candidats = 0;

    int total_votes = 0;
    int votes_valides = 0;
    int votes_annules = 0;

    char ligne[LIGNE_MAX];
    int lecture_votes = 0;

    // Lecture des données
    while (fgets(ligne, sizeof(ligne), f_in)) {
        // Supprimer le retour à la ligne
        ligne[strcspn(ligne, "\r\n")] = '\0';

        // Trouver le premier caractère non blanc
        char *p = ligne;
        while (*p && isspace((unsigned char)*p)) {
            p++;
        }

        // Ignorer les lignes vides
        if (*p == '\0') continue;

        // Si la ligne commence par un chiffre, on est arrivé aux votes
        if (isdigit((unsigned char)*p)) {
            lecture_votes = 1;

            // Traiter les votes présents sur cette ligne
            int vote, decalage;
            while (sscanf(p, "%d%n", &vote, &decalage) == 1) {
                total_votes++;
                if (vote >= 1 && vote <= nb_candidats) {
                    scores[vote - 1]++;
                    votes_valides++;
                } else {
                    fprintf(f_out, "Vote invalide : %d\n", vote);
                    votes_annules++;
                }
                p += decalage;
            }
            break; // Sortir pour continuer à lire les votes potentiels suivants
        } else {
            // C'est un nom de candidat
            if (nb_candidats < MAX_CANDIDATS) {
                strcpy(candidats[nb_candidats], p);
                nb_candidats++;
            }
        }
    }

    // Lire les votes restants (s'ils s'étendent sur plusieurs lignes)
    int vote;
    while (fscanf(f_in, "%d", &vote) == 1) {
        total_votes++;
        if (vote >= 1 && vote <= nb_candidats) {
            scores[vote - 1]++;
            votes_valides++;
        } else {
            fprintf(f_out, "Vote invalide : %d\n", vote);
            votes_annules++;
        }
    }

    // Écriture des statistiques globales
    fprintf(f_out, "Nombre d'électeurs : %d\n", total_votes);
    fprintf(f_out, "Nombre de votes valides : %d\n", votes_valides);
    fprintf(f_out, "Nombre de votes annules : %d\n", votes_annules);

    // Écriture des scores par candidat
    fprintf(f_out, "Candidat score\n");
    int max_score = -1;
    for (int i = 0; i < nb_candidats; i++) {
        fprintf(f_out, "%s %d\n", candidats[i], scores[i]);
        if (scores[i] > max_score) {
            max_score = scores[i];
        }
    }

    // Détermination et affichage du/des gagnant(s)
    fprintf(f_out, "Les gagnants:\n");
    for (int i = 0; i < nb_candidats; i++) {
        if (scores[i] == max_score) {
            fprintf(f_out, "%s\n", candidats[i]);
        }
    }

    // Fermeture des fichiers
    fclose(f_in);
    fclose(f_out);

    printf("Traitement termine avec succes. Consultez 'resultats.txt'.\n");
    return 0;
}
