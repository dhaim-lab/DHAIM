#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CANDIDATES 50   /* nombre maximum de candidats          */
#define MAX_VOTES     1000  /* nombre maximum de bulletins          */
#define NAME_LEN      100   /* longueur maximale d'un nom           */

int main(void)
{
    FILE *fileIn, *fileOut;

    char candidateNames[MAX_CANDIDATES][NAME_LEN];
    int  candidateVotes[MAX_CANDIDATES] = {0};
    int  invalidList[MAX_VOTES];                /* valeurs des bulletins nuls */

    int numOfCandidates = 0;
    int totalVotes = 0, invalidVotes = 0, maxVotes = 0;
    int vote, i;
    int maxNameWidth = 0;

    /* ---------- Ouverture du fichier d'entree ---------- */
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    /* ---------- Lecture des noms des candidats ----------
       Un nom est une ligne qui ne commence pas par un chiffre. */
    while (numOfCandidates < MAX_CANDIDATES &&
           fscanf(fileIn, " %99[^\n]", candidateNames[numOfCandidates]) == 1) {

        /* si la ligne commence par un chiffre -> c'est la ligne des votes */
        if (candidateNames[numOfCandidates][0] >= '0' &&
            candidateNames[numOfCandidates][0] <= '9') {
            break;
        }
        numOfCandidates++;
    }

    /* ---------- Lecture et depouillement des votes ----------
       La derniere chaine lue contient peut-etre deja la ligne des votes. */
    {
        char *token = candidateNames[numOfCandidates];
        if (numOfCandidates < MAX_CANDIDATES &&
            token[0] >= '0' && token[0] <= '9') {

            char *p = strtok(token, " \t");
            while (p != NULL) {
                vote = atoi(p);
                totalVotes++;
                if (vote >= 1 && vote <= numOfCandidates) {
                    candidateVotes[vote - 1]++;
                } else {
                    if (invalidVotes < MAX_VOTES)
                        invalidList[invalidVotes] = vote;
                    invalidVotes++;
                }
                p = strtok(NULL, " \t");
            }
        }
    }

    /* le reste des votes (s'ils sont sur plusieurs lignes) */
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            candidateVotes[vote - 1]++;
        } else {
            if (invalidVotes < MAX_VOTES)
                invalidList[invalidVotes] = vote;
            invalidVotes++;
        }
    }

    fclose(fileIn);

    /* ---------- Recherche du score maximal ---------- */
    for (i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] > maxVotes)
            maxVotes = candidateVotes[i];
    }

    /* ---------- Largeur de la colonne des noms ---------- */
    maxNameWidth = (int)strlen("Candidat");
    for (i = 0; i < numOfCandidates; i++) {
        int len = (int)strlen(candidateNames[i]);
        if (len > maxNameWidth)
            maxNameWidth = len;
    }
    maxNameWidth += 2;   /* petit espace avant la colonne "score" */

    /* ---------- Ecriture des resultats ---------- */
    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    for (i = 0; i < invalidVotes && i < MAX_VOTES; i++)
        fprintf(fileOut, "Vote invalide : %d\n", invalidList[i]);

    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", totalVotes - invalidVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidVotes);

    fprintf(fileOut, "%-*s%s\n", maxNameWidth, "Candidat", "score");
    for (i = 0; i < numOfCandidates; i++)
        fprintf(fileOut, "%-*s%d\n", maxNameWidth,
                candidateNames[i], candidateVotes[i]);

    fprintf(fileOut, "Les gagnants:\n");
    for (i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] == maxVotes)
            fprintf(fileOut, "%s\n", candidateNames[i]);
    }

    fclose(fileOut);

    printf("Resultats ecrits dans resultats.txt\n");
    return EXIT_SUCCESS;
}
