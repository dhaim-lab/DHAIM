/* ---------------------------------------------------------------
   Depouillement d'une election.
   Entree  : votes.txt  -> les noms des candidats (1 par ligne)
                           puis la liste des votes (des entiers)
   Sortie  : resultats.txt
   --------------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CAND 100    /* nombre maximum de candidats          */
#define MAX_LIG  256    /* longueur maximale d'une ligne du fichier */

int main(void)
{
    FILE *fin, *fout;
    char ligne[MAX_LIG];
    char noms[MAX_CAND][MAX_LIG];
    int  scores[MAX_CAND] = {0};

    int nbCandidats = 0;     /* nombre de candidats lus      */
    int nbElecteurs = 0;     /* nombre total de bulletins    */
    int nbValides   = 0;     /* bulletins valides            */
    int nbAnnules   = 0;     /* bulletins nuls               */
    int i, max;

    /* ---------- ouverture des fichiers ---------- */
    fin = fopen("votes.txt", "r");
    if (fin == NULL) {
        printf("Erreur : impossible d'ouvrir votes.txt\n");
        return 1;
    }

    fout = fopen("resultats.txt", "w");
    if (fout == NULL) {
        printf("Erreur : impossible de creer resultats.txt\n");
        fclose(fin);
        return 1;
    }

    /* ---------- lecture du fichier ---------- */
    while (fgets(ligne, sizeof(ligne), fin) != NULL) {

        char *p;
        size_t len = strlen(ligne);

        /* suppression du '\n', '\r' et des espaces de fin */
        while (len > 0 && (ligne[len-1] == '\n' || ligne[len-1] == '\r' ||
                           ligne[len-1] == ' '  || ligne[len-1] == '\t'))
            ligne[--len] = '\0';

        if (len == 0)              /* ligne vide : on l'ignore */
            continue;

        p = ligne;
        while (*p == ' ' || *p == '\t')   /* on saute les espaces du debut */
            p++;

        if (isdigit((unsigned char)*p)) {
            /* ----- c'est une ligne de votes ----- */
            int v, lu;
            while (sscanf(p, "%d%n", &v, &lu) == 1) {
                p += lu;
                nbElecteurs++;

                if (v >= 1 && v <= nbCandidats) {     /* vote valide */
                    scores[v-1]++;
                    nbValides++;
                } else {                              /* vote annule */
                    nbAnnules++;
                    fprintf(fout, "Vote invalide : %d\n", v);
                }
            }
        } else {
            /* ----- c'est un nom de candidat ----- */
            if (nbCandidats < MAX_CAND) {
                strcpy(noms[nbCandidats], p);
                scores[nbCandidats] = 0;
                nbCandidats++;
            }
        }
    }

    /* ---------- ecriture des resultats ---------- */
    fprintf(fout, "Nombre d'electeurs : %d\n", nbElecteurs);
    fprintf(fout, "Nombre de votes valides : %d\n", nbValides);
    fprintf(fout, "Nombre de votes annules : %d\n\n", nbAnnules);

    fprintf(fout, "%-20s %s\n", "Candidat", "score");
    for (i = 0; i < nbCandidats; i++)
        fprintf(fout, "%-20s %d\n", noms[i], scores[i]);

    /* ---------- recherche du (des) gagnant(s) ---------- */
    max = 0;
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] > max)
            max = scores[i];

    fprintf(fout, "\nLes gagnants:\n");
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] == max)
            fprintf(fout, "%s\n", noms[i]);

    fclose(fin);
    fclose(fout);

    printf("Depouillement termine : voir le fichier resultats.txt\n");
    return 0;
}
