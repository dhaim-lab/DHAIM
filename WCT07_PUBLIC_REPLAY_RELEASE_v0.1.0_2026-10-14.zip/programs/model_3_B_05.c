#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 50
#define MAX_NOM_LEN 100
#define MAX_VOTES 500

int main() {
    FILE *fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    char candidats[MAX_CANDIDATS][MAX_NOM_LEN];
    int score[MAX_CANDIDATS] = {0};
    int votesInvalides[MAX_VOTES];
    int nbCandidats = 0;
    int nbVotesInvalides = 0;
    int totalVotes = 0;

    char ligne[256];

    // 1. Lire le fichier ligne par ligne
    while (fgets(ligne, sizeof(ligne), fileIn)) {
        // Enlever le saut de ligne (\r\n)
        ligne[strcspn(ligne, "\r\n")] = '\0';

        // Ignorer les espaces de début
        char *ptr = ligne;
        while (*ptr == ' ' || *ptr == '\t') ptr++;

        if (*ptr == '\0') continue; // Ligne vide

        // Si la ligne commence par un chiffre, c'est le début des votes
        if (isdigit((unsigned char)*ptr)) {
            int vote, decalage;
            // Lire tous les votes de cette ligne
            while (sscanf(ptr, "%d%n", &vote, &decalage) == 1) {
                totalVotes++;
                if (vote >= 1 && vote <= nbCandidats) {
                    score[vote - 1]++;
                } else {
                    votesInvalides[nbVotesInvalides++] = vote;
                }
                ptr += decalage;
            }

            // Lire les votes restants (s'ils s'étendent sur plusieurs lignes)
            while (fscanf(fileIn, "%d", &vote) == 1) {
                totalVotes++;
                if (vote >= 1 && vote <= nbCandidats) {
                    score[vote - 1]++;
                } else {
                    votesInvalides[nbVotesInvalides++] = vote;
                }
            }
            break;
        } else {
            // C'est un nom de candidat
            if (nbCandidats < MAX_CANDIDATS) {
                strncpy(candidats[nbCandidats], ptr, MAX_NOM_LEN - 1);
                candidats[nbCandidats][MAX_NOM_LEN - 1] = '\0';
                nbCandidats++;
            }
        }
    }

    fclose(fileIn);

    // 2. Ouvrir le fichier de sortie resultats.txt
    FILE *fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    // Écrire les votes invalides individuels
    for (int i = 0; i < nbVotesInvalides; i++) {
        fprintf(fileOut, "Vote invalide : %d\n", votesInvalides[i]);
    }

    // Statistiques globales
    int votesValides = totalVotes - nbVotesInvalides;
    fprintf(fileOut, "Nombre d'électeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", votesValides);
    fprintf(fileOut, "Nombre de votes annules : %d\n", nbVotesInvalides);

    // Calcul de la largeur pour aligner la colonne 'score'
    int maxLen = strlen("Candidat");
    for (int i = 0; i < nbCandidats; i++) {
        int len = strlen(candidats[i]);
        if (len > maxLen) {
            maxLen = len;
        }
    }
    int colWidth = maxLen + 4; // Espacement entre le nom le plus long et le score

    // Écriture de la table des scores alignée
    fprintf(fileOut, "%-*s score\n", colWidth, "Candidat");

    int maxScore = 0;
    for (int i = 0; i < nbCandidats; i++) {
        fprintf(fileOut, "%-*s %d\n", colWidth, candidats[i], score[i]);
        if (score[i] > maxScore) {
            maxScore = score[i];
        }
    }

    // Écriture du ou des gagnants
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < nbCandidats; i++) {
        if (score[i] == maxScore) {
            fprintf(fileOut, "%s\n", candidats[i]);
        }
    }

    fclose(fileOut);
    return EXIT_SUCCESS;
}
