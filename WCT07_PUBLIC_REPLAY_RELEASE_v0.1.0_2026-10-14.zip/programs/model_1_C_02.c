#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM 100
#define MAX_LIGNE 1024

int main(void)
{
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[MAX_CANDIDATS][MAX_NOM];
    int scores[MAX_CANDIDATS] = {0};

    char ligne[MAX_LIGNE];
    int nombreCandidats = 0;
    int totalVotes = 0;
    int votesValides = 0;
    int votesAnnules = 0;
    int lectureVotes = 0;

    fichierVotes = fopen("votes.txt", "r");
    if (fichierVotes == NULL) {
        fprintf(stderr, "Erreur : impossible d'ouvrir votes.txt\n");
        return EXIT_FAILURE;
    }

    fichierResultats = fopen("resultats.txt", "w");
    if (fichierResultats == NULL) {
        fprintf(stderr, "Erreur : impossible de créer resultats.txt\n");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    while (fgets(ligne, sizeof(ligne), fichierVotes) != NULL) {
        char *debut = ligne;
        char *fin;

        /* Ignorer les espaces placés au début de la ligne. */
        while (isspace((unsigned char)*debut)) {
            debut++;
        }

        /* Ignorer les lignes vides. */
        if (*debut == '\0') {
            continue;
        }

        /*
         * Avant de rencontrer les votes, chaque ligne non numérique
         * représente le nom d'un candidat.
         */
        if (!lectureVotes) {
            strtol(debut, &fin, 10);

            if (fin == debut) {
                size_t longueur;

                if (nombreCandidats >= MAX_CANDIDATS) {
                    fprintf(stderr, "Nombre maximal de candidats dépassé.\n");
                    fclose(fichierVotes);
                    fclose(fichierResultats);
                    return EXIT_FAILURE;
                }

                /* Enlever le retour à la ligne. */
                longueur = strcspn(debut, "\r\n");
                debut[longueur] = '\0';

                strncpy(candidats[nombreCandidats], debut, MAX_NOM - 1);
                candidats[nombreCandidats][MAX_NOM - 1] = '\0';

                nombreCandidats++;
                continue;
            }

            /* La première ligne numérique marque le début des votes. */
            lectureVotes = 1;
        }

        /* Lire tous les votes présents sur la ligne. */
        while (*debut != '\0') {
            long vote;

            while (isspace((unsigned char)*debut)) {
                debut++;
            }

            if (*debut == '\0') {
                break;
            }

            vote = strtol(debut, &fin, 10);

            if (fin == debut) {
                /* Ignorer un caractère non numérique inattendu. */
                debut++;
                continue;
            }

            totalVotes++;

            if (vote >= 1 && vote <= nombreCandidats) {
                scores[vote - 1]++;
                votesValides++;
            } else {
                fprintf(fichierResultats, "Vote invalide : %ld\n", vote);
                votesAnnules++;
            }

            debut = fin;
        }
    }

    fprintf(fichierResultats, "Nombre d'électeurs : %d\n", totalVotes);
    fprintf(fichierResultats, "Nombre de votes valides : %d\n", votesValides);
    fprintf(fichierResultats, "Nombre de votes annules : %d\n", votesAnnules);

    fprintf(fichierResultats, "Candidat score\n");

    for (int i = 0; i < nombreCandidats; i++) {
        fprintf(fichierResultats, "%s %d\n", candidats[i], scores[i]);
    }

    /* Chercher le meilleur score. */
    int meilleurScore = 0;

    for (int i = 0; i < nombreCandidats; i++) {
        if (scores[i] > meilleurScore) {
            meilleurScore = scores[i];
        }
    }

    /* Afficher tous les gagnants en cas d'égalité. */
    fprintf(fichierResultats, "Les gagnants:\n");

    for (int i = 0; i < nombreCandidats; i++) {
        if (scores[i] == meilleurScore) {
            fprintf(fichierResultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichierVotes);
    fclose(fichierResultats);

    return EXIT_SUCCESS;
}
