#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CANDIDATS   50    /* nombre maximum de candidats          */
#define MAX_NOM        100    /* longueur maximale d'un nom           */
#define MAX_VOTES     1000    /* nombre maximum de bulletins          */

int main(void)
{
    FILE *fEntree, *fSortie;

    char nomsCandidats[MAX_CANDIDATS][MAX_NOM];
    int  scores[MAX_CANDIDATS] = {0};
    int  votesInvalides[MAX_VOTES];

    int nbCandidats   = 0;
    int nbElecteurs   = 0;   /* total des bulletins          */
    int nbValides     = 0;
    int nbAnnules     = 0;
    int scoreMax      = 0;
    int largeurNom    = 0;
    int i, vote;

    /* ---------- 1. Ouverture du fichier d'entree ---------- */
    fEntree = fopen("votes.txt", "r");
    if (fEntree == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    /* ---------- 2. Lecture des noms des candidats ----------
       Un nom est une ligne qui ne commence pas par un chiffre. */
    while (nbCandidats < MAX_CANDIDATS) {
        int c = fgetc(fEntree);

        if (c == EOF)            break;
        if (c == '\n' || c == '\r') continue;        /* ligne vide    */
        if (c >= '0' && c <= '9') { ungetc(c, fEntree); break; } /* debut des votes */

        ungetc(c, fEntree);
        if (fscanf(fEntree, "%99[^\n]", nomsCandidats[nbCandidats]) != 1)
            break;

        /* suppression d'un eventuel '\r' (fichiers Windows) */
        size_t len = strlen(nomsCandidats[nbCandidats]);
        while (len > 0 && (nomsCandidats[nbCandidats][len-1] == '\r' ||
                           nomsCandidats[nbCandidats][len-1] == ' '))
            nomsCandidats[nbCandidats][--len] = '\0';

        if (len > (size_t)largeurNom)
            largeurNom = (int)len;

        nbCandidats++;
    }

    if (nbCandidats == 0) {
        fprintf(stderr, "Aucun candidat trouve dans votes.txt\n");
        fclose(fEntree);
        return EXIT_FAILURE;
    }

    /* ---------- 3. Lecture et depouillement des votes ---------- */
    while (fscanf(fEntree, "%d", &vote) == 1) {
        nbElecteurs++;

        if (vote >= 1 && vote <= nbCandidats) {
            scores[vote - 1]++;
            nbValides++;
        } else {
            if (nbAnnules < MAX_VOTES)
                votesInvalides[nbAnnules] = vote;
            nbAnnules++;
        }
    }
    fclose(fEntree);

    /* ---------- 4. Recherche du meilleur score ---------- */
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] > scoreMax)
            scoreMax = scores[i];

    /* ---------- 5. Ecriture des resultats ---------- */
    fSortie = fopen("resultats.txt", "w");
    if (fSortie == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    /* 5.a : la liste des votes invalides */
    for (i = 0; i < nbAnnules && i < MAX_VOTES; i++)
        fprintf(fSortie, "Vote invalide : %d\n", votesInvalides[i]);

    /* 5.b : les statistiques */
    fprintf(fSortie, "Nombre d'electeurs : %d\n",      nbElecteurs);
    fprintf(fSortie, "Nombre de votes valides : %d\n", nbValides);
    fprintf(fSortie, "Nombre de votes annules : %d\n", nbAnnules);

    /* 5.c : le tableau des scores, aligne */
    if (largeurNom < 8) largeurNom = 8;              /* "Candidat" */
    fprintf(fSortie, "%-*s   %s\n", largeurNom, "Candidat", "score");
    for (i = 0; i < nbCandidats; i++)
        fprintf(fSortie, "%-*s   %3d\n", largeurNom,
                nomsCandidats[i], scores[i]);

    /* 5.d : le(s) gagnant(s) */
    fprintf(fSortie, "Les gagnants:\n");
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] == scoreMax)
            fprintf(fSortie, "%s\n", nomsCandidats[i]);

    fclose(fSortie);

    printf("Traitement termine : voir le fichier resultats.txt\n");
    return EXIT_SUCCESS;
}
