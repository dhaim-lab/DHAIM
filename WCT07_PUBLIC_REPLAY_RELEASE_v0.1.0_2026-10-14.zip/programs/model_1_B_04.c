#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUM_CANDIDATES 7
#define MAX_NAME_LENGTH 100

int main(void)
{
    FILE *inputFile;
    FILE *outputFile;

    char candidates[NUM_CANDIDATES][MAX_NAME_LENGTH];
    int scores[NUM_CANDIDATES] = {0};

    int totalVotes = 0;
    int validVotes = 0;
    int invalidVotes = 0;
    int maximumScore = 0;
    int maximumNameLength = 0;
    int vote;
    int i;

    /* Ouvrir votes.txt en lecture */
    inputFile = fopen("votes.txt", "r");

    if (inputFile == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    /* Ouvrir resultats.txt en écriture */
    outputFile = fopen("resultats.txt", "w");

    if (outputFile == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        fclose(inputFile);
        return EXIT_FAILURE;
    }

    /*
     * Lire les sept noms des candidats.
     * Chaque nom occupe une ligne.
     */
    for (i = 0; i < NUM_CANDIDATES; i++) {
        if (fgets(candidates[i], sizeof(candidates[i]), inputFile) == NULL) {
            fprintf(stderr, "Erreur : nombre de candidats insuffisant.\n");
            fclose(inputFile);
            fclose(outputFile);
            return EXIT_FAILURE;
        }

        /* Supprimer \n ou \r\n à la fin du nom */
        candidates[i][strcspn(candidates[i], "\r\n")] = '\0';

        /* Chercher la longueur du nom le plus long */
        {
            int nameLength = (int)strlen(candidates[i]);

            if (nameLength > maximumNameLength) {
                maximumNameLength = nameLength;
            }
        }
    }

    /* Lire et compter tous les votes */
    while (fscanf(inputFile, "%d", &vote) == 1) {
        totalVotes++;

        if (vote >= 1 && vote <= NUM_CANDIDATES) {
            scores[vote - 1]++;
            validVotes++;
        } else {
            /*
             * Le numéro du vote invalide est affiché,
             * pas seulement le nombre de votes invalides.
             */
            fprintf(outputFile, "Vote invalide : %d\n", vote);
            invalidVotes++;
        }
    }

    /* Déterminer le score maximal */
    for (i = 0; i < NUM_CANDIDATES; i++) {
        if (scores[i] > maximumScore) {
            maximumScore = scores[i];
        }
    }

    /* Écrire les statistiques générales */
    fprintf(outputFile, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(outputFile, "Nombre de votes valides : %d\n", validVotes);
    fprintf(outputFile, "Nombre de votes annules : %d\n", invalidVotes);

    /* En-tête avec colonnes alignées */
    fprintf(outputFile, "%-*s  %s\n",
            maximumNameLength, "Candidat", "Score");

    /* Écrire les candidats et leurs scores */
    for (i = 0; i < NUM_CANDIDATES; i++) {
        fprintf(outputFile, "%-*s  %d\n",
                maximumNameLength,
                candidates[i],
                scores[i]);
    }

    /* Écrire tous les gagnants en cas d'égalité */
    fprintf(outputFile, "Les gagnants:\n");

    for (i = 0; i < NUM_CANDIDATES; i++) {
        if (scores[i] == maximumScore) {
            fprintf(outputFile, "%s\n", candidates[i]);
        }
    }

    fclose(inputFile);
    fclose(outputFile);

    printf("Les resultats ont ete enregistres dans resultats.txt\n");

    return EXIT_SUCCESS;
}
