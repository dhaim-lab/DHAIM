#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATES 100
#define MAX_NAME_LEN 100
#define MAX_INVALID 100

int main() {
    FILE *fileIn, *fileOut;
    char candidateNames[MAX_CANDIDATES][MAX_NAME_LEN];
    int candidateVotes[MAX_CANDIDATES] = {0};
    int invalidList[MAX_INVALID];
    int numOfCandidates = 0;
    int totalVotes = 0, invalidCount = 0;
    int maxVotes = 0;
    char line[256];

    // 1. Ouvrir le fichier "votes.txt" en lecture
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    // 2. Lire les candidats jusqu'à atteindre la ligne des votes (commençant par un chiffre)
    while (fgets(line, sizeof(line), fileIn) != NULL) {
        // Enlever le saut de ligne (\r\n ou \n)
        line[strcspn(line, "\r\n")] = '\0';

        // Sauter les lignes vides éventuelles
        if (strlen(line) == 0) {
            continue;
        }

        // Si la ligne commence par un chiffre, c'est le début des votes
        if (isdigit((unsigned char)line[0])) {
            // Traiter cette première ligne de votes
            char *token = strtok(line, " \t");
            while (token != NULL) {
                int vote = atoi(token);
                totalVotes++;
                if (vote >= 1 && vote <= numOfCandidates) {
                    candidateVotes[vote - 1]++;
                } else {
                    if (invalidCount < MAX_INVALID) {
                        invalidList[invalidCount++] = vote;
                    }
                }
                token = strtok(NULL, " \t");
            }
            break; // Sortir pour lire le reste des votes si nécessaire
        } else {
            // C'est un nom de candidat
            if (numOfCandidates < MAX_CANDIDATES) {
                strncpy(candidateNames[numOfCandidates], line, MAX_NAME_LEN - 1);
                candidateNames[numOfCandidates][MAX_NAME_LEN - 1] = '\0';
                numOfCandidates++;
            }
        }
    }

    // 3. Lire le reste des votes (s'ils s'étalent sur d'autres lignes)
    int vote;
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            candidateVotes[vote - 1]++;
        } else {
            if (invalidCount < MAX_INVALID) {
                invalidList[invalidCount++] = vote;
            }
        }
    }

    fclose(fileIn);

    // 4. Trouver le score maximum pour déterminer les gagnants
    for (int i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] > maxVotes) {
            maxVotes = candidateVotes[i];
        }
    }

    // 5. Calculer la largeur maximale des noms pour aligner la colonne "score"
    int maxNameLen = (int)strlen("Candidat");
    for (int i = 0; i < numOfCandidates; i++) {
        int len = (int)strlen(candidateNames[i]);
        if (len > maxNameLen) {
            maxNameLen = len;
        }
    }
    // Espace de sécurité entre le nom le plus long et le score
    int colWidth = maxNameLen + 2;

    // 6. Ouvrir "resultats.txt" et écrire la sortie
    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    // Afficher chaque vote invalide individuellement
    for (int i = 0; i < invalidCount; i++) {
        fprintf(fileOut, "Vote invalide : %d\n", invalidList[i]);
    }

    // Afficher les totaux
    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", totalVotes - invalidCount);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidCount);

    // En-tête avec colonnes alignées
    fprintf(fileOut, "%-*s score\n", colWidth, "Candidat");

    // Lignes de chaque candidat avec score aligné
    for (int i = 0; i < numOfCandidates; i++) {
        fprintf(fileOut, "%-*s %d\n", colWidth, candidateNames[i], candidateVotes[i]);
    }

    // Gagnant(s)
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] == maxVotes) {
            fprintf(fileOut, "%s\n", candidateNames[i]);
        }
    }

    fclose(fileOut);

    return EXIT_SUCCESS;
}
