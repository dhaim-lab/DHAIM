#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM       100
#define MAX_LIGNE     1024

/* Traite une ligne contenant des votes */
void traiterVotes(char *ligne,
                  int scores[],
                  int nombreCandidats,
                  int *nombreElecteurs,
                  int *votesValides,
                  int *votesAnnules,
                  FILE *sortie)
{
    char *position = ligne;
    char *fin;
    long vote;

    while (*position != '\0') {
        /* Ignorer les espaces */
        while (isspace((unsigned char)*position)) {
            position++;
        }

        if (*position == '\0') {
            break;
        }

        vote = strtol(position, &fin, 10);

        /* Si aucun nombre n'a été trouvé, ignorer le caractère */
        if (position == fin) {
            position++;
            continue;
        }

        (*nombreElecteurs)++;

        if (vote >= 1 && vote <= nombreCandidats) {
            scores[vote - 1]++;
            (*votesValides)++;
        } else {
            fprintf(sortie, "Vote invalide : %ld\n", vote);
            (*votesAnnules)++;
        }

        position = fin;
    }
}

int main(void)
{
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[MAX_CANDIDATS][MAX_NOM];
    int scores[MAX_CANDIDATS] = {0};

    char ligne[MAX_LIGNE];
    char *debut;
    char *finNombre;

    int nombreCandidats = 0;
    int nombreElecteurs = 0;
    int votesValides = 0;
    int votesAnnules = 0;
    int votesCommences = 0;

    int largeurMax;
    int scoreMaximum = 0;
    int i;

    fichierVotes = fopen("votes.txt", "r");

    if (fichierVotes == NULL) {
        perror("Impossible d'ouvrir votes.txt");
        return EXIT_FAILURE;
    }

    fichierResultats = fopen("resultats.txt", "w");

    if (fichierResultats == NULL) {
        perror("Impossible d'ouvrir resultats.txt");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    /*
     * Lecture du fichier :
     * - les lignes qui ne commencent pas par un nombre sont des candidats ;
     * - à partir de la première ligne numérique, on traite les votes.
     */
    while (fgets(ligne, sizeof(ligne), fichierVotes) != NULL) {
        /* Supprimer \n et \r à la fin de la ligne */
        ligne[strcspn(ligne, "\r\n")] = '\0';

        debut = ligne;

        /* Ignorer les espaces au début pour tester la ligne */
        while (isspace((unsigned char)*debut)) {
            debut++;
        }

        /* Ignorer les lignes vides */
        if (*debut == '\0') {
            continue;
        }

        if (!votesCommences) {
            /*
             * Vérifier si la ligne commence par un nombre.
             * Si oui, cette ligne contient les votes.
             */
            strtol(debut, &finNombre, 10);

            if (finNombre != debut) {
                votesCommences = 1;

                traiterVotes(
                    debut,
                    scores,
                    nombreCandidats,
                    &nombreElecteurs,
                    &votesValides,
                    &votesAnnules,
                    fichierResultats
                );
            } else {
                if (nombreCandidats >= MAX_CANDIDATS) {
                    fprintf(stderr, "Trop de candidats.\n");
                    fclose(fichierVotes);
                    fclose(fichierResultats);
                    return EXIT_FAILURE;
                }

                strncpy(
                    candidats[nombreCandidats],
                    debut,
                    MAX_NOM - 1
                );

                candidats[nombreCandidats][MAX_NOM - 1] = '\0';
                nombreCandidats++;
            }
        } else {
            /*
             * Les votes peuvent également continuer
             * sur plusieurs lignes.
             */
            traiterVotes(
                debut,
                scores,
                nombreCandidats,
                &nombreElecteurs,
                &votesValides,
                &votesAnnules,
                fichierResultats
            );
        }
    }

    fclose(fichierVotes);

    if (nombreCandidats == 0) {
        fprintf(stderr, "Aucun candidat trouvé dans votes.txt.\n");
        fclose(fichierResultats);
        return EXIT_FAILURE;
    }

    /* Trouver la largeur du nom le plus long pour l'alignement */
    largeurMax = (int)strlen("Candidat");

    for (i = 0; i < nombreCandidats; i++) {
        int longueur = (int)strlen(candidats[i]);

        if (longueur > largeurMax) {
            largeurMax = longueur;
        }
    }

    /* Trouver le score maximum */
    for (i = 0; i < nombreCandidats; i++) {
        if (scores[i] > scoreMaximum) {
            scoreMaximum = scores[i];
        }
    }

    /* Écriture des statistiques */
    fprintf(
        fichierResultats,
        "Nombre d'électeurs : %d\n",
        nombreElecteurs
    );

    fprintf(
        fichierResultats,
        "Nombre de votes valides : %d\n",
        votesValides
    );

    fprintf(
        fichierResultats,
        "Nombre de votes annules : %d\n",
        votesAnnules
    );

    /* Affichage aligné des scores */
    fprintf(
        fichierResultats,
        "%-*s  Score\n",
        largeurMax,
        "Candidat"
    );

    for (i = 0; i < nombreCandidats; i++) {
        fprintf(
            fichierResultats,
            "%-*s  %d\n",
            largeurMax,
            candidats[i],
            scores[i]
        );
    }

    /* Affichage de tous les gagnants en cas d'égalité */
    fprintf(fichierResultats, "Les gagnants:\n");

    for (i = 0; i < nombreCandidats; i++) {
        if (scores[i] == scoreMaximum) {
            fprintf(fichierResultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichierResultats);

    return EXIT_SUCCESS;
}
