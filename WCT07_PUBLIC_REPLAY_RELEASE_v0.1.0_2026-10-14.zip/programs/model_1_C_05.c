#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM 256
#define MAX_LIGNE 4096

/* Supprime les espaces et les retours à la ligne au début et à la fin. */
void nettoyer_ligne(char *ligne)
{
    char *debut = ligne;
    size_t longueur;

    while (isspace((unsigned char)*debut)) {
        debut++;
    }

    if (debut != ligne) {
        memmove(ligne, debut, strlen(debut) + 1);
    }

    longueur = strlen(ligne);

    while (longueur > 0 &&
           isspace((unsigned char)ligne[longueur - 1])) {
        ligne[--longueur] = '\0';
    }
}

/* Vérifie si une ligne contient uniquement des nombres entiers. */
int est_ligne_de_votes(const char *ligne)
{
    const char *p = ligne;
    char *fin;
    int nombre_trouve = 0;

    while (*p != '\0') {
        while (isspace((unsigned char)*p)) {
            p++;
        }

        if (*p == '\0') {
            break;
        }

        strtol(p, &fin, 10);

        if (fin == p) {
            return 0;
        }

        nombre_trouve = 1;
        p = fin;

        if (*p != '\0' && !isspace((unsigned char)*p)) {
            return 0;
        }
    }

    return nombre_trouve;
}

/* Traite un vote et met à jour les statistiques. */
void traiter_vote(long vote,
                  int nombre_candidats,
                  long scores[],
                  long *nombre_electeurs,
                  long *votes_valides,
                  long *votes_annules,
                  FILE *sortie)
{
    (*nombre_electeurs)++;

    if (vote >= 1 && vote <= nombre_candidats) {
        scores[vote - 1]++;
        (*votes_valides)++;
    } else {
        fprintf(sortie, "Vote invalide : %ld\n", vote);
        (*votes_annules)++;
    }
}

/* Traite tous les votes présents sur une ligne. */
void traiter_ligne_votes(const char *ligne,
                         int nombre_candidats,
                         long scores[],
                         long *nombre_electeurs,
                         long *votes_valides,
                         long *votes_annules,
                         FILE *sortie)
{
    const char *p = ligne;
    char *fin;
    long vote;

    while (*p != '\0') {
        while (isspace((unsigned char)*p)) {
            p++;
        }

        if (*p == '\0') {
            break;
        }

        vote = strtol(p, &fin, 10);

        if (fin == p) {
            break;
        }

        traiter_vote(vote,
                     nombre_candidats,
                     scores,
                     nombre_electeurs,
                     votes_valides,
                     votes_annules,
                     sortie);

        p = fin;
    }
}

int main(void)
{
    FILE *fichier_votes;
    FILE *fichier_resultats;

    char candidats[MAX_CANDIDATS][MAX_NOM];
    long scores[MAX_CANDIDATS] = {0};
    char ligne[MAX_LIGNE];

    int nombre_candidats = 0;
    int votes_commences = 0;

    long nombre_electeurs = 0;
    long votes_valides = 0;
    long votes_annules = 0;

    long score_maximum = 0;
    int i;

    fichier_votes = fopen("votes.txt", "r");

    if (fichier_votes == NULL) {
        fprintf(stderr, "Erreur : impossible d'ouvrir votes.txt\n");
        return EXIT_FAILURE;
    }

    fichier_resultats = fopen("resultats.txt", "w");

    if (fichier_resultats == NULL) {
        fprintf(stderr, "Erreur : impossible de créer resultats.txt\n");
        fclose(fichier_votes);
        return EXIT_FAILURE;
    }

    while (fgets(ligne, sizeof(ligne), fichier_votes) != NULL) {
        nettoyer_ligne(ligne);

        if (ligne[0] == '\0') {
            continue;
        }

        /*
         * Avant la première ligne numérique, chaque ligne représente
         * le nom d'un candidat.
         */
        if (!votes_commences && !est_ligne_de_votes(ligne)) {
            if (nombre_candidats >= MAX_CANDIDATS) {
                fprintf(stderr, "Erreur : trop de candidats.\n");
                fclose(fichier_votes);
                fclose(fichier_resultats);
                return EXIT_FAILURE;
            }

            snprintf(candidats[nombre_candidats],
                     MAX_NOM,
                     "%s",
                     ligne);

            nombre_candidats++;
        } else {
            votes_commences = 1;

            traiter_ligne_votes(ligne,
                                nombre_candidats,
                                scores,
                                &nombre_electeurs,
                                &votes_valides,
                                &votes_annules,
                                fichier_resultats);
        }
    }

    fprintf(fichier_resultats,
            "Nombre d'électeurs : %ld\n",
            nombre_electeurs);

    fprintf(fichier_resultats,
            "Nombre de votes valides : %ld\n",
            votes_valides);

    fprintf(fichier_resultats,
            "Nombre de votes annules : %ld\n",
            votes_annules);

    fprintf(fichier_resultats, "Candidat score\n");

    for (i = 0; i < nombre_candidats; i++) {
        fprintf(fichier_resultats,
                "%s %ld\n",
                candidats[i],
                scores[i]);

        if (i == 0 || scores[i] > score_maximum) {
            score_maximum = scores[i];
        }
    }

    fprintf(fichier_resultats, "Les gagnants:\n");

    for (i = 0; i < nombre_candidats; i++) {
        if (scores[i] == score_maximum) {
            fprintf(fichier_resultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichier_votes);
    fclose(fichier_resultats);

    return EXIT_SUCCESS;
}
