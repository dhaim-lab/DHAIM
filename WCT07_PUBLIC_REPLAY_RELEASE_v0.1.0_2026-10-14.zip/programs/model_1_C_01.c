#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM 100
#define MAX_LIGNE 1024

int main(void)
{
    FILE *fVotes;
    FILE *fResultats;

    char candidats[MAX_CANDIDATS][MAX_NOM];
    int scores[MAX_CANDIDATS] = {0};

    char ligne[MAX_LIGNE];
    int nombreCandidats = 0;
    int totalVotes = 0;
    int votesValides = 0;
    int votesAnnules = 0;
    int lectureVotes = 0;

    fVotes = fopen("votes.txt", "r");
    if (fVotes == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    fResultats = fopen("resultats.txt", "w");
    if (fResultats == NULL) {
        perror("Erreur lors de la creation de resultats.txt");
        fclose(fVotes);
        return EXIT_FAILURE;
    }

    while (fgets(ligne, sizeof(ligne), fVotes) != NULL) {
        char *p = ligne;
        char *fin;
        long vote;

        /* Ignorer les espaces au début de la ligne */
        while (isspace((unsigned char)*p)) {
            p++;
        }

        /* Ignorer les lignes vides */
        if (*p == '\0') {
            continue;
        }

        /*
         * Si la ligne commence par un nombre, alors les votes commencent.
         */
        vote = strtol(p, &fin, 10);

        if (!lectureVotes && fin == p) {
            /* La ligne contient le nom d'un candidat */
            size_t longueur;

            if (nombreCandidats >= MAX_CANDIDATS) {
                fprintf(stderr, "Nombre maximal de candidats depasse.\n");
                fclose(fVotes);
                fclose(fResultats);
                return EXIT_FAILURE;
            }

            /* Supprimer le retour à la ligne */
            longueur = strcspn(p, "\r\n");
            p[longueur] = '\0';

            strncpy(candidats[nombreCandidats], p, MAX_NOM - 1);
            candidats[nombreCandidats][MAX_NOM - 1] = '\0';

            nombreCandidats++;
        } else {
            lectureVotes = 1;

            /*
             * Lire tous les votes présents sur cette ligne.
             */
            while (*p != '\0') {
                while (isspace((unsigned char)*p)) {
                    p++;
                }

                if (*p == '\0') {
                    break;
                }

                vote = strtol(p, &fin, 10);

                if (fin == p) {
                    /* Caractère non numérique inattendu */
                    p++;
                    continue;
                }

                totalVotes++;

                if (vote >= 1 && vote <= nombreCandidats) {
                    scores[vote - 1]++;
                    votesValides++;
                } else {
                    votesAnnules++;
                    fprintf(fResultats, "Vote invalide : %ld\n", vote);
                }

                p = fin;
            }
        }
    }

    fprintf(fResultats, "Nombre d'électeurs : %d\n", totalVotes);
    fprintf(fResultats, "Nombre de votes valides : %d\n", votesValides);
    fprintf(fResultats, "Nombre de votes annules : %d\n", votesAnnules);

    fprintf(fResultats, "Candidat score\n");

    for (int i = 0; i < nombreCandidats; i++) {
        fprintf(fResultats, "%s %d\n", candidats[i], scores[i]);
    }

    if (nombreCandidats > 0) {
        int scoreMaximum = scores[0];

        for (int i = 1; i < nombreCandidats; i++) {
            if (scores[i] > scoreMaximum) {
                scoreMaximum = scores[i];
            }
        }

        fprintf(fResultats, "Les gagnants:\n");

        for (int i = 0; i < nombreCandidats; i++) {
            if (scores[i] == scoreMaximum) {
                fprintf(fResultats, "%s\n", candidats[i]);
            }
        }
    }

    fclose(fVotes);
    fclose(fResultats);

    return EXIT_SUCCESS;
}
