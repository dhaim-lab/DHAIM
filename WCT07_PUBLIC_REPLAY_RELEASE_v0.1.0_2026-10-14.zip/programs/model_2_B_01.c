#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CANDIDATS   50    /* nombre maximum de candidats          */
#define MAX_VOTES      1000   /* nombre maximum de votes              */
#define LONG_NOM        100   /* longueur maximale d'un nom           */

int main(void)
{
    FILE *fileIn, *fileOut;

    char candidats[MAX_CANDIDATS][LONG_NOM];      /* noms des candidats     */
    int  scores[MAX_CANDIDATS] = {0};             /* score de chaque candidat*/
    int  votesInvalides[MAX_VOTES];               /* liste des votes nuls    */

    int nbCandidats = 0, nbInvalides = 0;
    int totalVotes = 0, votesValides = 0;
    int vote, i, maxScore = 0, largeurNom = 0;

    char ligne[LONG_NOM];

    /* ---------- Ouverture du fichier d'entree ---------- */
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    /* ---------- Lecture des noms des candidats ----------
       Une ligne qui ne commence pas par un chiffre est un nom.      */
    while (nbCandidats < MAX_CANDIDATS &&
           fgets(ligne, sizeof(ligne), fileIn) != NULL) {

        ligne[strcspn(ligne, "\r\n")] = '\0';     /* enlever le saut de ligne */

        if (ligne[0] == '\0')                     /* ligne vide : on ignore   */
            continue;

        if (ligne[0] >= '0' && ligne[0] <= '9') { /* debut des votes          */
            /* on traite cette ligne comme la premiere ligne de votes */
            char *p = ligne;
            while (sscanf(p, "%d", &vote) == 1) {
                totalVotes++;
                if (vote >= 1 && vote <= nbCandidats) {
                    scores[vote - 1]++;
                    votesValides++;
                } else if (nbInvalides < MAX_VOTES) {
                    votesInvalides[nbInvalides++] = vote;
                }
                /* avancer le pointeur apres le nombre lu */
                while (*p == ' ' || *p == '\t') p++;
                while (*p && *p != ' ' && *p != '\t') p++;
            }
            break;                                 /* on passe a fscanf        */
        }

        strcpy(candidats[nbCandidats], ligne);
        nbCandidats++;
    }

    /* ---------- Lecture du reste des votes ---------- */
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= nbCandidats) {
            scores[vote - 1]++;
            votesValides++;
        } else if (nbInvalides < MAX_VOTES) {
            votesInvalides[nbInvalides++] = vote;
        }
    }

    fclose(fileIn);

    /* ---------- Recherche du meilleur score ---------- */
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] > maxScore)
            maxScore = scores[i];

    /* ---------- Largeur de la colonne "Candidat" ---------- */
    largeurNom = (int)strlen("Candidat");
    for (i = 0; i < nbCandidats; i++) {
        int len = (int)strlen(candidats[i]);
        if (len > largeurNom)
            largeurNom = len;
    }
    largeurNom += 2;   /* petite marge entre le nom et le score */

    /* ---------- Ouverture du fichier de sortie ---------- */
    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    /* ---------- Votes invalides ---------- */
    for (i = 0; i < nbInvalides; i++)
        fprintf(fileOut, "Vote invalide : %d\n", votesInvalides[i]);

    /* ---------- Statistiques ---------- */
    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", votesValides);
    fprintf(fileOut, "Nombre de votes annules : %d\n", nbInvalides);

    /* ---------- Tableau des scores (aligne) ---------- */
    fprintf(fileOut, "%-*s%s\n", largeurNom, "Candidat", "score");
    for (i = 0; i < nbCandidats; i++)
        fprintf(fileOut, "%-*s%5d\n", largeurNom, candidats[i], scores[i]);

    /* ---------- Gagnant(s) ---------- */
    fprintf(fileOut, "Les gagnants:\n");
    for (i = 0; i < nbCandidats; i++)
        if (scores[i] == maxScore)
            fprintf(fileOut, "%s\n", candidats[i]);

    fclose(fileOut);

    printf("Traitement termine. Consultez le fichier resultats.txt\n");
    return EXIT_SUCCESS;
}
