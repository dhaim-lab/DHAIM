#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATES 50
#define MAX_NAME_LEN   100
#define MAX_VOTES      1000

int main(void) {
    FILE *fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    char candidateNames[MAX_CANDIDATES][MAX_NAME_LEN];
    int candidateCount = 0;
    char line[256];

    // 1. Read candidates until we reach the line that starts with digits
    while (fgets(line, sizeof(line), fileIn) != NULL) {
        // Strip trailing newline/carriage returns
        line[strcspn(line, "\r\n")] = '\0';

        // Skip potential empty lines
        if (strlen(line) == 0) {
            continue;
        }

        // Find first non-whitespace character
        int i = 0;
        while (line[i] == ' ' || line[i] == '\t') i++;

        // If the line starts with a digit, the candidate list is done
        if (isdigit((unsigned char)line[i])) {
            // Rewind file position back to read votes with fscanf
            fseek(fileIn, -((long)strlen(line) + 1), SEEK_CUR);
            break;
        }

        // Otherwise, store candidate name
        if (candidateCount < MAX_CANDIDATES) {
            strncpy(candidateNames[candidateCount], line, MAX_NAME_LEN - 1);
            candidateNames[candidateCount][MAX_NAME_LEN - 1] = '\0';
            candidateCount++;
        }
    }

    // 2. Read all votes
    int invalidVotesList[MAX_VOTES];
    int invalidCount = 0;
    int candidateScores[MAX_CANDIDATES] = {0};
    int totalVotes = 0;
    int vote;

    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= candidateCount) {
            candidateScores[vote - 1]++;
        } else {
            invalidVotesList[invalidCount++] = vote;
        }
    }

    fclose(fileIn);

    // 3. Find the maximum score among candidates
    int maxScore = 0;
    for (int i = 0; i < candidateCount; i++) {
        if (candidateScores[i] > maxScore) {
            maxScore = candidateScores[i];
        }
    }

    // 4. Calculate column width for aligned output
    // The minimum width is at least strlen("Candidat") which is 8
    int colWidth = 8;
    for (int i = 0; i < candidateCount; i++) {
        int len = (int)strlen(candidateNames[i]);
        if (len > colWidth) {
            colWidth = len;
        }
    }
    colWidth += 3; // add a comfortable spacing margin

    // 5. Write results to "resultats.txt"
    FILE *fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    // Print individual invalid votes
    for (int i = 0; i < invalidCount; i++) {
        fprintf(fileOut, "Vote invalide : %d\n", invalidVotesList[i]);
    }

    // Print summary counts
    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", totalVotes - invalidCount);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidCount);

    // Print aligned table
    fprintf(fileOut, "%-*s score\n", colWidth, "Candidat");
    for (int i = 0; i < candidateCount; i++) {
        fprintf(fileOut, "%-*s %d\n", colWidth, candidateNames[i], candidateScores[i]);
    }

    // Print winner(s)
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < candidateCount; i++) {
        if (candidateScores[i] == maxScore) {
            fprintf(fileOut, "%s\n", candidateNames[i]);
        }
    }

    fclose(fileOut);
    return EXIT_SUCCESS;
}
