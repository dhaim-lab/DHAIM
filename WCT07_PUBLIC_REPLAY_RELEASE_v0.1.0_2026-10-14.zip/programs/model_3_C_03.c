#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM_LEN 100
#define MAX_VOTES 10000

int main() {
    FILE *fin = fopen("votes.txt", "r");
    if (fin == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier votes.txt\n");
        return 1;
    }

    char noms[MAX_CANDIDATS][MAX_NOM_LEN];
    int scores[MAX_CANDIDATS] = {0};
    int votes_invalides[MAX_VOTES];

    int nb_candidats = 0;
    int nb_valides = 0;
    int nb_invalides = 0;

    char ligne[256];
    int vote;

    // 1. Lecture des noms des candidats et de la première ligne de votes
    while (fgets(ligne, sizeof(ligne), fin) != NULL) {
        // Supprimer les sauts de ligne à la fin
        ligne[strcspn(ligne, "\r\n")] = '\0';

        // Ignorer les espaces de début
        char *ptr = ligne;
        while (isspace((unsigned char)*ptr)) {
            ptr++;
        }

        // Ligne vide
        if (*ptr == '\0') {
            continue;
        }

        // Si la ligne commence par un chiffre, on a atteint la liste des votes
        if (isdigit((unsigned char)*ptr)) {
            int offset;
            while (sscanf(ptr, "%d%n", &vote, &offset) == 1) {
                if (vote >= 1 && vote <= nb_candidats) {
                    scores[vote - 1]++;
                    nb_valides++;
                } else {
                    votes_invalides[nb_invalides++] = vote;
                }
                ptr += offset;
            }
            break; // Sortie de la boucle des noms
        } else {
            // C'est un nom de candidat
            strncpy(noms[nb_candidats], ptr, MAX_NOM_LEN - 1);
            noms[nb_candidats][MAX_NOM_LEN - 1] = '\0';
            nb_candidats++;
        }
    }

    // 2. Continuer la lecture des votes restants (si étalés sur plusieurs lignes)
    while (fscanf(fin, "%d", &vote) == 1) {
        if (vote >= 1 && vote <= nb_candidats) {
            scores[vote - 1]++;
            nb_valides++;
        } else {
            votes_invalides[nb_invalides++] = vote;
        }
    }

    fclose(fin);

    // 3. Écriture des résultats dans resultats.txt
    FILE *fout = fopen("resultats.txt", "w");
    if (fout == NULL) {
        printf("Erreur : impossible de créer le fichier resultats.txt\n");
        return 1;
    }

    // Affichage des votes invalides
    for (int i = 0; i < nb_invalides; i++) {
        fprintf(fout, "Vote invalide : %d\n", votes_invalides[i]);
    }

    // Statistiques globales
    int total_electeurs = nb_valides + nb_invalides;
    fprintf(fout, "Nombre d'électeurs : %d\n", total_electeurs);
    fprintf(fout, "Nombre de votes valides : %d\n", nb_valides);
    fprintf(fout, "Nombre de votes annules : %d\n", nb_invalides);

    // Tableau des scores et recherche du score maximal
    fprintf(fout, "Candidat score\n");
    int score_max = 0;
    for (int i = 0; i < nb_candidats; i++) {
        fprintf(fout, "%s %d\n", noms[i], scores[i]);
        if (scores[i] > score_max) {
            score_max = scores[i];
        }
    }

    // Comptage du nombre de gagnants
    int nb_gagnants = 0;
    for (int i = 0; i < nb_candidats; i++) {
        if (scores[i] == score_max) {
            nb_gagnants++;
        }
    }

    // Affichage du ou des gagnants
    if (nb_gagnants > 1) {
        fprintf(fout, "Les gagnants:\n");
    } else {
        fprintf(fout, "Le gagnant:\n");
    }

    for (int i = 0; i < nb_candidats; i++) {
        if (scores[i] == score_max) {
            fprintf(fout, "%s\n", noms[i]);
        }
    }

    fclose(fout);
    printf("Les résultats ont été générés avec succès dans resultats.txt\n");

    return 0;
}
