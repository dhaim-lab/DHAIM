#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM 100
#define MAX_LIGNE 4096

/* Supprime les caractères de fin de ligne */
void supprimerFinLigne(char *chaine)
{
    chaine[strcspn(chaine, "\r\n")] = '\0';
}

/* Vérifie si une ligne commence par un nombre */
int estLigneDeVotes(const char *ligne)
{
    while (isspace((unsigned char)*ligne))
        ligne++;

    return isdigit((unsigned char)*ligne) ||
           ((*ligne == '+' || *ligne == '-') &&
            isdigit((unsigned char)ligne[1]));
}

int main(void)
{
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[MAX_CANDIDATS][MAX_NOM];
    int scores[MAX_CANDIDATS] = {0};

    char ligne[MAX_LIGNE];
    int nombreCandidats = 0;
    int lectureVotes = 0;

    int nombreElecteurs = 0;
    int votesValides = 0;
    int votesAnnules = 0;

    fichierVotes = fopen("votes.txt", "r");

    if (fichierVotes == NULL) {
        fprintf(stderr, "Erreur : impossible d'ouvrir votes.txt\n");
        return EXIT_FAILURE;
    }

    fichierResultats = fopen("resultats.txt", "w");

    if (fichierResultats == NULL) {
        fprintf(stderr, "Erreur : impossible de creer resultats.txt\n");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    while (fgets(ligne, sizeof(ligne), fichierVotes) != NULL) {
        supprimerFinLigne(ligne);

        /* Ignorer les lignes vides */
        if (ligne[0] == '\0')
            continue;

        if (!lectureVotes && !estLigneDeVotes(ligne)) {
            if (nombreCandidats >= MAX_CANDIDATS) {
                fprintf(stderr, "Erreur : trop de candidats.\n");
                fclose(fichierVotes);
                fclose(fichierResultats);
                return EXIT_FAILURE;
            }

            strncpy(candidats[nombreCandidats], ligne, MAX_NOM - 1);
            candidats[nombreCandidats][MAX_NOM - 1] = '\0';
            nombreCandidats++;
        } else {
            char *element;

            lectureVotes = 1;

            element = strtok(ligne, " \t");

            while (element != NULL) {
                int vote = (int)strtol(element, NULL, 10);

                nombreElecteurs++;

                if (vote >= 1 && vote <= nombreCandidats) {
                    scores[vote - 1]++;
                    votesValides++;
                } else {
                    fprintf(fichierResultats,
                            "Vote invalide : %d\n", vote);
                    votesAnnules++;
                }

                element = strtok(NULL, " \t");
            }
        }
    }

    fprintf(fichierResultats,
            "Nombre d'électeurs : %d\n", nombreElecteurs);
    fprintf(fichierResultats,
            "Nombre de votes valides : %d\n", votesValides);
    fprintf(fichierResultats,
            "Nombre de votes annules : %d\n", votesAnnules);

    fprintf(fichierResultats, "Candidat score\n");

    for (int i = 0; i < nombreCandidats; i++) {
        fprintf(fichierResultats,
                "%s %d\n", candidats[i], scores[i]);
    }

    if (nombreCandidats > 0) {
        int scoreMaximum = scores[0];

        for (int i = 1; i < nombreCandidats; i++) {
            if (scores[i] > scoreMaximum)
                scoreMaximum = scores[i];
        }

        fprintf(fichierResultats, "Les gagnants:\n");

        for (int i = 0; i < nombreCandidats; i++) {
            if (scores[i] == scoreMaximum)
                fprintf(fichierResultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichierVotes);
    fclose(fichierResultats);

    return EXIT_SUCCESS;
}
