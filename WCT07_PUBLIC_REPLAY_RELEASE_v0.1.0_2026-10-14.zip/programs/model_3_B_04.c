#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 50
#define MAX_NOM_LEN 100
#define MAX_VOTES 1000

int main() {
    FILE *fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    char candidats[MAX_CANDIDATS][MAX_NOM_LEN];
    int scores[MAX_CANDIDATS] = {0};
    int votesInvalides[MAX_VOTES];
    int nbCandidats = 0;
    int totalVotes = 0;
    int nbValides = 0;
    int nbInvalides = 0;

    char ligne[1024];

    // 1. Lecture des candidats et des votes
    while (fgets(ligne, sizeof(ligne), fileIn)) {
        // Ignorer les espaces de début
        char *ptr = ligne;
        while (*ptr == ' ' || *ptr == '\t') ptr++;

        // Ligne vide
        if (*ptr == '\0' || *ptr == '\r' || *ptr == '\n') continue;

        // Si la ligne commence par un chiffre, c'est le début des votes
        if (isdigit((unsigned char)*ptr)) {
            int vote, offset;
            // Lire tous les votes présents sur cette ligne
            while (sscanf(ptr, "%d%n", &vote, &offset) == 1) {
                ptr += offset;
                totalVotes++;
                if (vote >= 1 && vote <= nbCandidats) {
                    scores[vote - 1]++;
                    nbValides++;
                } else {
                    votesInvalides[nbInvalides++] = vote;
                }
            }
            // Lire les éventuels votes restants dans le fichier
            while (fscanf(fileIn, "%d", &vote) == 1) {
                totalVotes++;
                if (vote >= 1 && vote <= nbCandidats) {
                    scores[vote - 1]++;
                    nbValides++;
                } else {
                    votesInvalides[nbInvalides++] = vote;
                }
            }
            break; // Tous les votes ont été lus
        } else {
            // C'est un nom de candidat
            ptr[strcspn(ptr, "\r\n")] = '\0'; // Supprimer le saut de ligne
            strncpy(candidats[nbCandidats], ptr, MAX_NOM_LEN - 1);
            candidats[nbCandidats][MAX_NOM_LEN - 1] = '\0';
            nbCandidats++;
        }
    }
    fclose(fileIn);

    // 2. Déterminer le score maximal
    int maxScore = 0;
    for (int i = 0; i < nbCandidats; i++) {
        if (scores[i] > maxScore) {
            maxScore = scores[i];
        }
    }

    // 3. Calculer la largeur maximale pour aligner la colonne "score"
    int maxLargeur = strlen("Candidat");
    for (int i = 0; i < nbCandidats; i++) {
        int len = strlen(candidats[i]);
        if (len > maxLargeur) {
            maxLargeur = len;
        }
    }
    maxLargeur += 4; // Espacement entre le nom et le score

    // 4. Écriture dans resultats.txt
    FILE *fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        return EXIT_FAILURE;
    }

    // Liste des votes invalides
    for (int i = 0; i < nbInvalides; i++) {
        fprintf(fileOut, "Vote invalide : %d\n", votesInvalides[i]);
    }

    // Statistiques
    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", nbValides);
    fprintf(fileOut, "Nombre de votes annules : %d\n", nbInvalides);

    // Tableau des scores avec alignement
    fprintf(fileOut, "%-*s score\n", maxLargeur, "Candidat");
    for (int i = 0; i < nbCandidats; i++) {
        fprintf(fileOut, "%-*s %d\n", maxLargeur, candidats[i], scores[i]);
    }

    // Les gagnants
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < nbCandidats; i++) {
        if (scores[i] == maxScore) {
            fprintf(fileOut, "%s\n", candidats[i]);
        }
    }

    fclose(fileOut);
    return EXIT_SUCCESS;
}
