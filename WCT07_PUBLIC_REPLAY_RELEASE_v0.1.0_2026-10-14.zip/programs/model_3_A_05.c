#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATES 50
#define MAX_NAME_LEN 100
#define MAX_INVALID_VOTES 1000

int main(void) {
    FILE *fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    char candidateNames[MAX_CANDIDATES][MAX_NAME_LEN];
    int candidateVotes[MAX_CANDIDATES] = {0};
    int invalidList[MAX_INVALID_VOTES];
    int numOfCandidates = 0;
    int invalidCount = 0;
    int totalVotes = 0;
    int maxVotes = 0;

    char line[1024];

    /* 1. Read candidate names until we encounter the line with numbers */
    while (fgets(line, sizeof(line), fileIn) != NULL) {
        /* Remove trailing newline or carriage return characters */
        line[strcspn(line, "\r\n")] = '\0';

        /* Skip empty lines if any */
        if (strlen(line) == 0) {
            continue;
        }

        /* If the line starts with a digit, we have reached the votes */
        if (isdigit((unsigned char)line[0])) {
            /* Parse votes from this line */
            char *token = strtok(line, " \t");
            while (token != NULL) {
                int vote = atoi(token);
                totalVotes++;
                if (vote >= 1 && vote <= numOfCandidates) {
                    candidateVotes[vote - 1]++;
                } else {
                    invalidList[invalidCount++] = vote;
                }
                token = strtok(NULL, " \t");
            }
            break; /* Done reading candidates */
        }

        /* Otherwise, store candidate name */
        if (numOfCandidates < MAX_CANDIDATES) {
            strncpy(candidateNames[numOfCandidates], line, MAX_NAME_LEN - 1);
            candidateNames[numOfCandidates][MAX_NAME_LEN - 1] = '\0';
            numOfCandidates++;
        }
    }

    /* 2. Read any remaining votes across subsequent lines (if any) */
    int vote;
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            candidateVotes[vote - 1]++;
        } else {
            invalidList[invalidCount++] = vote;
        }
    }

    fclose(fileIn);

    /* 3. Determine maximum vote count */
    for (int i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] > maxVotes) {
            maxVotes = candidateVotes[i];
        }
    }

    /* 4. Find maximum width needed for column alignment */
    int colWidth = (int)strlen("Candidat");
    for (int i = 0; i < numOfCandidates; i++) {
        int len = (int)strlen(candidateNames[i]);
        if (len > colWidth) {
            colWidth = len;
        }
    }
    colWidth += 4; /* Add padding spaces between columns */

    /* 5. Write the final results to resultats.txt */
    FILE *fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    /* List each invalid vote */
    for (int i = 0; i < invalidCount; i++) {
        fprintf(fileOut, "Vote invalide : %d\n", invalidList[i]);
    }

    int validVotes = totalVotes - invalidCount;
    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", validVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidCount);

    /* Table header */
    fprintf(fileOut, "%-*s score\n", colWidth, "Candidat");

    /* Candidate rows with aligned scores */
    for (int i = 0; i < numOfCandidates; i++) {
        fprintf(fileOut, "%-*s %d\n", colWidth, candidateNames[i], candidateVotes[i]);
    }

    /* Winner(s) */
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] == maxVotes) {
            fprintf(fileOut, "%s\n", candidateNames[i]);
        }
    }

    fclose(fileOut);
    return EXIT_SUCCESS;
}
