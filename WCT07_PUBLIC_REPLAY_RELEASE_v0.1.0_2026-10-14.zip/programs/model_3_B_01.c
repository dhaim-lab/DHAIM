#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATES 50
#define NAME_LEN 100
#define MAX_INVALID 1000

int main() {
    FILE *fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    char candidates[MAX_CANDIDATES][NAME_LEN];
    int numOfCandidates = 0;
    char line[256];
    char voteLine[2048] = "";

    // 1. Lire les candidats jusqu'à tomber sur la ligne des votes (commence par un chiffre)
    while (fgets(line, sizeof(line), fileIn) != NULL) {
        // Supprimer le retour à la ligne
        line[strcspn(line, "\r\n")] = '\0';

        // Sauter les lignes vides éventuelles
        if (strlen(line) == 0) continue;

        // Trouver le premier caractère non vide
        char *p = line;
        while (isspace((unsigned char)*p)) p++;

        // Si la ligne commence par un chiffre, c'est la ligne des votes
        if (isdigit((unsigned char)*p)) {
            strcpy(voteLine, line);
            break;
        }

        // Sinon, c'est un nom de candidat
        if (numOfCandidates < MAX_CANDIDATES) {
            strncpy(candidates[numOfCandidates], line, NAME_LEN - 1);
            candidates[numOfCandidates][NAME_LEN - 1] = '\0';
            numOfCandidates++;
        }
    }

    int candidateScores[MAX_CANDIDATES] = {0};
    int invalidList[MAX_INVALID];
    int invalidCount = 0;
    int totalVotes = 0;
    int validVotes = 0;
    int vote;

    // 2. Traiter d'abord la ligne de votes détectée
    if (strlen(voteLine) > 0) {
        char *token = strtok(voteLine, " \t\r\n");
        while (token != NULL) {
            vote = atoi(token);
            totalVotes++;
            if (vote >= 1 && vote <= numOfCandidates) {
                validVotes++;
                candidateScores[vote - 1]++;
            } else {
                if (invalidCount < MAX_INVALID) {
                    invalidList[invalidCount++] = vote;
                }
            }
            token = strtok(NULL, " \t\r\n");
        }
    }

    // Lire les votes restants s'il y en a d'autres dans le fichier
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            validVotes++;
            candidateScores[vote - 1]++;
        } else {
            if (invalidCount < MAX_INVALID) {
                invalidList[invalidCount++] = vote;
            }
        }
    }

    fclose(fileIn);

    // 3. Calculer le score maximum et la largeur max pour l'alignement
    int maxScore = 0;
    int maxLen = (int)strlen("Candidat");

    for (int i = 0; i < numOfCandidates; i++) {
        if (candidateScores[i] > maxScore) {
            maxScore = candidateScores[i];
        }
        int len = (int)strlen(candidates[i]);
        if (len > maxLen) {
            maxLen = len;
        }
    }

    // 4. Écrire le résultat dans "resultats.txt"
    FILE *fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de la creation du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    // Affichage des votes invalides détectés
    for (int i = 0; i < invalidCount; i++) {
        fprintf(fileOut, "Vote invalide : %d\n", invalidList[i]);
    }

    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", validVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidCount);

    // En-tête : "score" sera aligné avec la colonne des nombres
    int colWidth = maxLen + 2;
    fprintf(fileOut, "%-*s score\n", colWidth, "Candidat");

    // Lignes des candidats avec scores alignés
    for (int i = 0; i < numOfCandidates; i++) {
        fprintf(fileOut, "%-*s %d\n", colWidth, candidates[i], candidateScores[i]);
    }

    // Gagnant(s)
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < numOfCandidates; i++) {
        if (candidateScores[i] == maxScore) {
            fprintf(fileOut, "%s\n", candidates[i]);
        }
    }

    fclose(fileOut);
    return EXIT_SUCCESS;
}
