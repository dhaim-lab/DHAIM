#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM       200
#define MAX_LIGNE     1000

/*
 * Traite une ligne contenant des votes.
 */
void traiterVotes(
    char *ligne,
    FILE *fichierResultats,
    int scores[],
    int nombreCandidats,
    int *nombreElecteurs,
    int *votesValides,
    int *votesAnnules
) {
    char *position = ligne;
    char *fin;
    long vote;

    while (1) {
        /* Ignorer les espaces */
        while (isspace((unsigned char)*position)) {
            position++;
        }

        if (*position == '\0') {
            break;
        }

        vote = strtol(position, &fin, 10);

        /* Aucun entier trouvé */
        if (fin == position) {
            position++;
            continue;
        }

        (*nombreElecteurs)++;

        if (vote >= 1 && vote <= nombreCandidats) {
            scores[vote - 1]++;
            (*votesValides)++;
        } else {
            fprintf(fichierResultats, "Vote invalide : %ld\n", vote);
            (*votesAnnules)++;
        }

        position = fin;
    }
}

int main(void) {
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[MAX_CANDIDATS][MAX_NOM];
    int scores[MAX_CANDIDATS] = {0};

    char ligne[MAX_LIGNE];
    char *position;
    char *fin;

    int nombreCandidats = 0;
    int nombreElecteurs = 0;
    int votesValides = 0;
    int votesAnnules = 0;

    int largeurNom;
    int longueur;
    int scoreMaximum = 0;
    int i;

    /* Ouvrir votes.txt en lecture */
    fichierVotes = fopen("votes.txt", "r");

    if (fichierVotes == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    /* Ouvrir resultats.txt en écriture */
    fichierResultats = fopen("resultats.txt", "w");

    if (fichierResultats == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    /*
     * Lire le fichier ligne par ligne.
     * Les lignes qui ne commencent pas par un nombre sont considérées
     * comme des noms de candidats.
     */
    while (fgets(ligne, sizeof(ligne), fichierVotes) != NULL) {
        position = ligne;

        /* Ignorer les espaces au début de la ligne */
        while (isspace((unsigned char)*position)) {
            position++;
        }

        /* Ignorer les lignes vides */
        if (*position == '\0') {
            continue;
        }

        /*
         * Vérifier si la ligne commence par un entier.
         * Si oui, nous sommes arrivés à la liste des votes.
         */
        strtol(position, &fin, 10);

        if (fin != position) {
            traiterVotes(
                position,
                fichierResultats,
                scores,
                nombreCandidats,
                &nombreElecteurs,
                &votesValides,
                &votesAnnules
            );

            break;
        }

        if (nombreCandidats >= MAX_CANDIDATS) {
            fprintf(stderr, "Erreur : trop de candidats.\n");
            fclose(fichierVotes);
            fclose(fichierResultats);
            return EXIT_FAILURE;
        }

        /* Supprimer \n et \r à la fin du nom */
        ligne[strcspn(ligne, "\r\n")] = '\0';

        strncpy(
            candidats[nombreCandidats],
            ligne,
            MAX_NOM - 1
        );

        candidats[nombreCandidats][MAX_NOM - 1] = '\0';
        nombreCandidats++;
    }

    /*
     * Traiter les éventuelles lignes de votes suivantes.
     */
    while (fgets(ligne, sizeof(ligne), fichierVotes) != NULL) {
        traiterVotes(
            ligne,
            fichierResultats,
            scores,
            nombreCandidats,
            &nombreElecteurs,
            &votesValides,
            &votesAnnules
        );
    }

    fclose(fichierVotes);

    /* Déterminer la largeur du plus long nom */
    largeurNom = (int)strlen("Candidat");

    for (i = 0; i < nombreCandidats; i++) {
        longueur = (int)strlen(candidats[i]);

        if (longueur > largeurNom) {
            largeurNom = longueur;
        }
    }

    /* Déterminer le score maximum */
    for (i = 0; i < nombreCandidats; i++) {
        if (scores[i] > scoreMaximum) {
            scoreMaximum = scores[i];
        }
    }

    /* Écrire le résumé */
    fprintf(
        fichierResultats,
        "Nombre d'électeurs : %d\n",
        nombreElecteurs
    );

    fprintf(
        fichierResultats,
        "Nombre de votes valides : %d\n",
        votesValides
    );

    fprintf(
        fichierResultats,
        "Nombre de votes annules : %d\n",
        votesAnnules
    );

    /* Afficher les scores avec des colonnes alignées */
    fprintf(
        fichierResultats,
        "%-*s  %s\n",
        largeurNom,
        "Candidat",
        "Score"
    );

    for (i = 0; i < nombreCandidats; i++) {
        fprintf(
            fichierResultats,
            "%-*s  %d\n",
            largeurNom,
            candidats[i],
            scores[i]
        );
    }

    /* Afficher tous les gagnants */
    fprintf(fichierResultats, "Les gagnants:\n");

    for (i = 0; i < nombreCandidats; i++) {
        if (scores[i] == scoreMaximum) {
            fprintf(fichierResultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichierResultats);

    return EXIT_SUCCESS;
}
