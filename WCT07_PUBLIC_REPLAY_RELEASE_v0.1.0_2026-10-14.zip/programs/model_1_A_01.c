#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NOMBRE_CANDIDATS 7
#define TAILLE_NOM 100

int main(void)
{
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[NOMBRE_CANDIDATS][TAILLE_NOM];
    int scores[NOMBRE_CANDIDATS] = {0};

    int nombreElecteurs = 0;
    int votesValides = 0;
    int votesAnnules = 0;
    int scoreMaximum = 0;
    int largeurMaximum = 0;
    int vote;
    int i;

    /* Ouverture du fichier contenant les votes */
    fichierVotes = fopen("votes.txt", "r");

    if (fichierVotes == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    /* Ouverture du fichier de résultats */
    fichierResultats = fopen("resultats.txt", "w");

    if (fichierResultats == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    /* Lecture des 7 noms des candidats */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (fgets(candidats[i], TAILLE_NOM, fichierVotes) == NULL) {
            fprintf(stderr, "Erreur : nombre de candidats insuffisant.\n");
            fclose(fichierVotes);
            fclose(fichierResultats);
            return EXIT_FAILURE;
        }

        /* Suppression de '\n' ou '\r\n' à la fin du nom */
        candidats[i][strcspn(candidats[i], "\r\n")] = '\0';

        /* Recherche de la longueur du nom le plus long */
        if ((int)strlen(candidats[i]) > largeurMaximum) {
            largeurMaximum = (int)strlen(candidats[i]);
        }
    }

    /* Lecture et comptage des votes */
    while (fscanf(fichierVotes, "%d", &vote) == 1) {
        nombreElecteurs++;

        if (vote >= 1 && vote <= NOMBRE_CANDIDATS) {
            scores[vote - 1]++;
            votesValides++;
        } else {
            fprintf(fichierResultats, "Vote invalide : %d\n", vote);
            votesAnnules++;
        }
    }

    /* Recherche du score maximum */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (scores[i] > scoreMaximum) {
            scoreMaximum = scores[i];
        }
    }

    /* Écriture des informations générales */
    fprintf(fichierResultats,
            "Nombre d'electeurs : %d\n",
            nombreElecteurs);

    fprintf(fichierResultats,
            "Nombre de votes valides : %d\n",
            votesValides);

    fprintf(fichierResultats,
            "Nombre de votes annules : %d\n",
            votesAnnules);

    /*
     * %-*s :
     *   - signifie alignement à gauche ;
     *   * utilise largeurMaximum comme largeur de colonne.
     */
    fprintf(fichierResultats,
            "%-*s  %s\n",
            largeurMaximum,
            "Candidat",
            "Score");

    /* Écriture des scores alignés */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        fprintf(fichierResultats,
                "%-*s  %d\n",
                largeurMaximum,
                candidats[i],
                scores[i]);
    }

    /* Écriture du ou des gagnants */
    fprintf(fichierResultats, "Les gagnants:\n");

    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (scores[i] == scoreMaximum) {
            fprintf(fichierResultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichierVotes);
    fclose(fichierResultats);

    return EXIT_SUCCESS;
}
