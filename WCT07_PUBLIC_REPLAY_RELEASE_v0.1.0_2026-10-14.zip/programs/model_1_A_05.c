#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NOMBRE_CANDIDATS 7
#define TAILLE_NOM 100

int main(void)
{
    FILE *fichierVotes;
    FILE *fichierResultats;

    char candidats[NOMBRE_CANDIDATS][TAILLE_NOM];
    int scores[NOMBRE_CANDIDATS] = {0};

    int nombreElecteurs = 0;
    int votesValides = 0;
    int votesAnnules = 0;
    int largeurMax = 0;
    int scoreMax = 0;
    int vote;
    int i;

    /* Ouverture du fichier contenant les candidats et les votes */
    fichierVotes = fopen("votes.txt", "r");

    if (fichierVotes == NULL) {
        perror("Erreur d'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    /* Lecture des 7 candidats, un candidat par ligne */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (fgets(candidats[i], TAILLE_NOM, fichierVotes) == NULL) {
            fprintf(stderr,
                    "Erreur : le fichier ne contient pas %d candidats.\n",
                    NOMBRE_CANDIDATS);
            fclose(fichierVotes);
            return EXIT_FAILURE;
        }

        /* Suppression de '\n' ou '\r\n' à la fin du nom */
        candidats[i][strcspn(candidats[i], "\r\n")] = '\0';

        /* Recherche de la longueur du nom le plus long */
        if ((int)strlen(candidats[i]) > largeurMax) {
            largeurMax = (int)strlen(candidats[i]);
        }
    }

    /* Ouverture du fichier de résultats */
    fichierResultats = fopen("resultats.txt", "w");

    if (fichierResultats == NULL) {
        perror("Erreur d'ouverture de resultats.txt");
        fclose(fichierVotes);
        return EXIT_FAILURE;
    }

    /* Lecture et traitement des votes */
    while (fscanf(fichierVotes, "%d", &vote) == 1) {
        nombreElecteurs++;

        if (vote >= 1 && vote <= NOMBRE_CANDIDATS) {
            scores[vote - 1]++;
            votesValides++;
        } else {
            fprintf(fichierResultats, "Vote invalide : %d\n", vote);
            votesAnnules++;
        }
    }

    fclose(fichierVotes);

    /* Recherche du meilleur score */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (scores[i] > scoreMax) {
            scoreMax = scores[i];
        }
    }

    /* Écriture des statistiques */
    fprintf(fichierResultats,
            "Nombre d'electeurs : %d\n",
            nombreElecteurs);

    fprintf(fichierResultats,
            "Nombre de votes valides : %d\n",
            votesValides);

    fprintf(fichierResultats,
            "Nombre de votes annules : %d\n",
            votesAnnules);

    /* En-tête aligné */
    fprintf(fichierResultats,
            "%-*s  %s\n",
            largeurMax,
            "Candidat",
            "score");

    /* Affichage des candidats et de leurs scores */
    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        fprintf(fichierResultats,
                "%-*s  %d\n",
                largeurMax,
                candidats[i],
                scores[i]);
    }

    /* Affichage du ou des gagnants */
    fprintf(fichierResultats, "Les gagnants:\n");

    for (i = 0; i < NOMBRE_CANDIDATS; i++) {
        if (scores[i] == scoreMax) {
            fprintf(fichierResultats, "%s\n", candidats[i]);
        }
    }

    fclose(fichierResultats);

    printf("Les resultats ont ete enregistres dans resultats.txt\n");

    return EXIT_SUCCESS;
}
