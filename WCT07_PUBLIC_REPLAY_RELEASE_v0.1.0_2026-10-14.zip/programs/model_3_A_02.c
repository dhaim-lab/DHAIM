#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATES 50
#define MAX_NAME_LEN 100
#define MAX_INVALID_VOTES 100

int main() {
    FILE *fileIn, *fileOut;
    char candidateNames[MAX_CANDIDATES][MAX_NAME_LEN];
    int candidateVotes[MAX_CANDIDATES] = {0};
    int invalidValues[MAX_INVALID_VOTES];
    int invalidCount = 0;
    int totalVotes = 0;
    int numOfCandidates = 0;
    int maxVotes = 0;
    char line[1024];

    // Ouvrir le fichier d'entrée
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    // 1. Lire les candidats
    // Une ligne est un candidat tant qu'elle ne commence pas par un chiffre
    while (fgets(line, sizeof(line), fileIn)) {
        // Supprimer le retour à la ligne (\n et \r)
        line[strcspn(line, "\r\n")] = '\0';

        // Ignorer les lignes vides accidentelles
        if (strlen(line) == 0) {
            continue;
        }

        // Si la ligne commence par un chiffre, on est arrivé aux votes
        if (isdigit((unsigned char)line[0])) {
            break;
        }

        // Enregistrer le nom du candidat
        if (numOfCandidates < MAX_CANDIDATES) {
            strncpy(candidateNames[numOfCandidates], line, MAX_NAME_LEN - 1);
            candidateNames[numOfCandidates][MAX_NAME_LEN - 1] = '\0';
            numOfCandidates++;
        }
    }

    // 2. Traiter les votes (en commençant par la ligne déjà lue qui contient des chiffres)
    do {
        char *ptr = line;
        int vote;
        int bytesRead;

        while (sscanf(ptr, "%d%n", &vote, &bytesRead) == 1) {
            ptr += bytesRead;
            totalVotes++;

            if (vote >= 1 && vote <= numOfCandidates) {
                candidateVotes[vote - 1]++;
            } else {
                if (invalidCount < MAX_INVALID_VOTES) {
                    invalidValues[invalidCount++] = vote;
                }
            }
        }
    } while (fgets(line, sizeof(line), fileIn));

    fclose(fileIn);

    // Déterminer le score maximal
    for (int i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] > maxVotes) {
            maxVotes = candidateVotes[i];
        }
    }

    // Trouver la longueur du nom le plus long pour l'alignement
    int maxNameLen = strlen("Candidat");
    for (int i = 0; i < numOfCandidates; i++) {
        int len = strlen(candidateNames[i]);
        if (len > maxNameLen) {
            maxNameLen = len;
        }
    }
    int colWidth = maxNameLen + 2; // Largeur de la colonne des noms

    // Ouvrir le fichier de sortie
    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    // 3. Écrire les résultats
    // Afficher le détail des votes invalides
    for (int i = 0; i < invalidCount; i++) {
        fprintf(fileOut, "Vote invalide : %d\n", invalidValues[i]);
    }

    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", totalVotes - invalidCount);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidCount);

    // En-tête du tableau aligné
    fprintf(fileOut, "%-*sScore\n", colWidth, "Candidat");

    // Lignes des candidats avec scores alignés sous "Score"
    for (int i = 0; i < numOfCandidates; i++) {
        fprintf(fileOut, "%-*s%d\n", colWidth, candidateNames[i], candidateVotes[i]);
    }

    // Gagnant(s)
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] == maxVotes) {
            fprintf(fileOut, "%s\n", candidateNames[i]);
        }
    }

    fclose(fileOut);
    return EXIT_SUCCESS;
}
