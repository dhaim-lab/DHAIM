#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATES 50
#define MAX_NAME_LEN 100
#define MAX_INVALID 100

int main(void) {
    FILE *fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    char candidates[MAX_CANDIDATES][MAX_NAME_LEN];
    int scores[MAX_CANDIDATES] = {0};
    int invalidList[MAX_INVALID];
    
    int candidateCount = 0;
    int totalVotes = 0;
    int validVotes = 0;
    int invalidVotes = 0;

    char line[256];

    // 1. Read candidates until reaching the line with votes (digits)
    while (fgets(line, sizeof(line), fileIn)) {
        // Strip trailing \r and \n
        line[strcspn(line, "\r\n")] = '\0';

        // Skip completely empty lines if any
        if (strlen(line) == 0) {
            continue;
        }

        // Check if the line starts with a digit (meaning votes have started)
        if (isdigit((unsigned char)line[0])) {
            // Process the votes found on this line
            char *token = strtok(line, " \t");
            while (token != NULL) {
                int vote = atoi(token);
                totalVotes++;
                if (vote >= 1 && vote <= candidateCount) {
                    scores[vote - 1]++;
                    validVotes++;
                } else {
                    if (invalidVotes < MAX_INVALID) {
                        invalidList[invalidVotes] = vote;
                    }
                    invalidVotes++;
                }
                token = strtok(NULL, " \t");
            }
            break; // Stop candidate reading loop
        } else {
            // Store candidate name
            if (candidateCount < MAX_CANDIDATES) {
                strncpy(candidates[candidateCount], line, MAX_NAME_LEN - 1);
                candidates[candidateCount][MAX_NAME_LEN - 1] = '\0';
                candidateCount++;
            }
        }
    }

    // 2. Read any remaining votes in the rest of the file
    int vote;
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= candidateCount) {
            scores[vote - 1]++;
            validVotes++;
        } else {
            if (invalidVotes < MAX_INVALID) {
                invalidList[invalidVotes] = vote;
            }
            invalidVotes++;
        }
    }

    fclose(fileIn);

    // 3. Find the maximum score
    int maxScore = 0;
    for (int i = 0; i < candidateCount; i++) {
        if (scores[i] > maxScore) {
            maxScore = scores[i];
        }
    }

    // 4. Calculate width for column alignment
    int colWidth = (int)strlen("Candidat");
    for (int i = 0; i < candidateCount; i++) {
        int len = (int)strlen(candidates[i]);
        if (len > colWidth) {
            colWidth = len;
        }
    }
    colWidth += 4; // Add spacing between name and score

    // 5. Write results to "resultats.txt"
    FILE *fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        return EXIT_FAILURE;
    }

    // Print invalid votes individually first
    for (int i = 0; i < invalidVotes && i < MAX_INVALID; i++) {
        fprintf(fileOut, "Vote invalide : %d\n", invalidList[i]);
    }

    // Print summary counts
    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", validVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidVotes);

    // Print aligned table
    fprintf(fileOut, "%-*s score\n", colWidth, "Candidat");
    for (int i = 0; i < candidateCount; i++) {
        fprintf(fileOut, "%-*s %d\n", colWidth, candidates[i], scores[i]);
    }

    // Print winner(s)
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < candidateCount; i++) {
        if (scores[i] == maxScore) {
            fprintf(fileOut, "%s\n", candidates[i]);
        }
    }

    fclose(fileOut);
    return EXIT_SUCCESS;
}
