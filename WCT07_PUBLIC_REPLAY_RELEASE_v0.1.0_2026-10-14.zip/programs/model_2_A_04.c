#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CANDIDATES 50
#define MAX_NAME_LEN   100

int main(void)
{
    FILE *fileIn, *fileOut;
    char candidateNames[MAX_CANDIDATES][MAX_NAME_LEN];
    int  candidateVotes[MAX_CANDIDATES] = {0};
    int  numOfCandidates = 0;
    int  totalVotes = 0, invalidVotes = 0, maxVotes = 0;
    int  vote, i, maxNameWidth = 0;

    /* ---------- Ouverture des fichiers ---------- */
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        fclose(fileIn);
        return EXIT_FAILURE;
    }

    /* ---------- Lecture des noms des candidats ---------- */
    /* Un nom par ligne ; on s'arrete des qu'une ligne commence par un chiffre */
    while (numOfCandidates < MAX_CANDIDATES) {
        long pos = ftell(fileIn);                 /* memoriser la position */
        char ligne[MAX_NAME_LEN];

        if (fgets(ligne, sizeof(ligne), fileIn) == NULL)
            break;

        ligne[strcspn(ligne, "\r\n")] = '\0';     /* enlever le saut de ligne */

        if (ligne[0] == '\0')                     /* ligne vide : on ignore */
            continue;

        if (ligne[0] >= '0' && ligne[0] <= '9') { /* debut des votes */
            fseek(fileIn, pos, SEEK_SET);         /* revenir en arriere */
            break;
        }

        strcpy(candidateNames[numOfCandidates], ligne);
        numOfCandidates++;
    }

    /* ---------- Largeur de la colonne des noms ---------- */
    maxNameWidth = (int)strlen("Candidat");
    for (i = 0; i < numOfCandidates; i++) {
        int len = (int)strlen(candidateNames[i]);
        if (len > maxNameWidth)
            maxNameWidth = len;
    }

    /* ---------- Lecture et comptage des votes ---------- */
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            candidateVotes[vote - 1]++;
        } else {
            fprintf(fileOut, "Vote invalide : %d\n", vote);
            invalidVotes++;
        }
    }
    fclose(fileIn);

    /* ---------- Score maximum ---------- */
    for (i = 0; i < numOfCandidates; i++)
        if (candidateVotes[i] > maxVotes)
            maxVotes = candidateVotes[i];

    /* ---------- Ecriture des resultats ---------- */
    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", totalVotes - invalidVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidVotes);

    fprintf(fileOut, "%-*s   %s\n", maxNameWidth, "Candidat", "score");
    for (i = 0; i < numOfCandidates; i++)
        fprintf(fileOut, "%-*s   %3d\n", maxNameWidth,
                candidateNames[i], candidateVotes[i]);

    fprintf(fileOut, "Les gagnants:\n");
    for (i = 0; i < numOfCandidates; i++)
        if (candidateVotes[i] == maxVotes)
            fprintf(fileOut, "%s\n", candidateNames[i]);

    fclose(fileOut);

    printf("Les resultats ont ete ecrits dans resultats.txt\n");
    return EXIT_SUCCESS;
}
