#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATS 100
#define MAX_NOM_LEN 100
#define MAX_VOTES 1000

int main() {
    FILE *f_in = fopen("votes.txt", "r");
    if (f_in == NULL) {
        printf("Erreur lors de l'ouverture du fichier votes.txt\n");
        return 1;
    }

    char candidats[MAX_CANDIDATS][MAX_NOM_LEN];
    int scores[MAX_CANDIDATS] = {0};
    int votes_invalides[MAX_VOTES];
    
    int nb_candidats = 0;
    int nb_electeurs = 0;
    int nb_valides = 0;
    int nb_annules = 0;

    char ligne[256];

    // 1. Lecture des noms de candidats jusqu'à atteindre la ligne des votes
    while (fgets(ligne, sizeof(ligne), f_in)) {
        // Ignorer les espaces en début de ligne
        char *ptr = ligne;
        while (isspace(*ptr)) ptr++;

        if (*ptr == '\0') continue; // Ligne vide

        // Si la ligne commence par un chiffre, on a atteint les votes
        if (isdigit(*ptr)) {
            // Traiter les nombres présents sur cette ligne
            int vote, offset;
            while (sscanf(ptr, "%d%n", &vote, &offset) == 1) {
                nb_electeurs++;
                if (vote >= 1 && vote <= nb_candidats) {
                    scores[vote - 1]++;
                    nb_valides++;
                } else {
                    votes_invalides[nb_annules++] = vote;
                }
                ptr += offset;
            }
            break; // On passe à la lecture du reste des votes
        } else {
            // C'est un nom de candidat
            ligne[strcspn(ligne, "\r\n")] = '\0'; // Retirer le saut de ligne
            strcpy(candidats[nb_candidats], ligne);
            nb_candidats++;
        }
    }

    // 2. Lecture du reste des votes (s'il y en a d'autres dans le fichier)
    int vote;
    while (fscanf(f_in, "%d", &vote) == 1) {
        nb_electeurs++;
        if (vote >= 1 && vote <= nb_candidats) {
            scores[vote - 1]++;
            nb_valides++;
        } else {
            votes_invalides[nb_annules++] = vote;
        }
    }

    fclose(f_in);

    // 3. Détermination du/des gagnant(s)
    int score_max = 0;
    for (int i = 0; i < nb_candidats; i++) {
        if (scores[i] > score_max) {
            score_max = scores[i];
        }
    }

    // 4. Écriture des résultats dans resultats.txt
    FILE *f_out = fopen("resultats.txt", "w");
    if (f_out == NULL) {
        printf("Erreur lors de la création du fichier resultats.txt\n");
        return 1;
    }

    // Affichage des votes invalides
    for (int i = 0; i < nb_annules; i++) {
        fprintf(f_out, "Vote invalide : %d\n", votes_invalides[i]);
    }

    // Statistiques des votes
    fprintf(f_out, "Nombre d'électeurs : %d\n", nb_electeurs);
    fprintf(f_out, "Nombre de votes valides : %d\n", nb_valides);
    fprintf(f_out, "Nombre de votes annules : %d\n", nb_annules);

    // Score par candidat
    fprintf(f_out, "Candidat score\n");
    for (int i = 0; i < nb_candidats; i++) {
        fprintf(f_out, "%s %d\n", candidats[i], scores[i]);
    }

    // Gagnant(s)
    fprintf(f_out, "Les gagnants:\n");
    for (int i = 0; i < nb_candidats; i++) {
        if (scores[i] == score_max) {
            fprintf(f_out, "%s\n", candidats[i]);
        }
    }

    fclose(f_out);

    printf("Les résultats ont été enregistrés avec succès dans resultats.txt\n");
    return 0;
}
