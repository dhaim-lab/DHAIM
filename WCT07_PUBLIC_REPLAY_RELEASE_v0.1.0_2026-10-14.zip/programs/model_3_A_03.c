#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_CANDIDATES 50
#define MAX_NAME_LEN 100

int main(void) {
    FILE *fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture de votes.txt");
        return EXIT_FAILURE;
    }

    char candidateNames[MAX_CANDIDATES][MAX_NAME_LEN];
    int candidateVotes[MAX_CANDIDATES] = {0};
    int numOfCandidates = 0;
    
    char line[256];
    long votesFilePos = 0;

    // 1. Lire les noms des candidats
    while (fgets(line, sizeof(line), fileIn) != NULL) {
        // Enlever le retour à la ligne (\n et \r)
        line[strcspn(line, "\r\n")] = '\0';

        // Sauter les lignes vides
        if (strlen(line) == 0) {
            continue;
        }

        // Si le premier caractère non-espace est un chiffre, c'est la liste des votes
        int i = 0;
        while (isspace(line[i])) i++;
        if (isdigit(line[i])) {
            // Revenir au début de cette ligne pour lire les entiers
            fseek(fileIn, votesFilePos, SEEK_SET);
            break;
        }

        // Sinon, c'est un nom de candidat
        if (numOfCandidates < MAX_CANDIDATES) {
            strncpy(candidateNames[numOfCandidates], line, MAX_NAME_LEN - 1);
            candidateNames[numOfCandidates][MAX_NAME_LEN - 1] = '\0';
            numOfCandidates++;
        }
        
        // Mémoriser la position courante dans le fichier
        votesFilePos = ftell(fileIn);
    }

    // Ouvrir le fichier de sortie
    FILE *fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture de resultats.txt");
        fclose(fileIn);
        return EXIT_FAILURE;
    }

    // 2. Traiter les votes
    int totalVotes = 0;
    int validVotes = 0;
    int invalidVotes = 0;
    int vote;

    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            validVotes++;
            candidateVotes[vote - 1]++;
        } else {
            invalidVotes++;
            // Imprimer chaque vote invalide au début du fichier
            fprintf(fileOut, "Vote invalide : %d\n", vote);
        }
    }

    fclose(fileIn);

    // 3. Afficher les statistiques globales
    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", validVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidVotes);

    // 4. Calculer la largeur maximale pour l'alignement des colonnes
    int maxNameLen = (int)strlen("Candidat");
    for (int i = 0; i < numOfCandidates; i++) {
        int len = (int)strlen(candidateNames[i]);
        if (len > maxNameLen) {
            maxNameLen = len;
        }
    }

    // Marge entre le nom le plus long et la colonne score
    int colWidth = maxNameLen + 3;

    // Afficher le tableau aligné
    fprintf(fileOut, "%-*s score\n", colWidth, "Candidat");

    int maxVotes = 0;
    for (int i = 0; i < numOfCandidates; i++) {
        fprintf(fileOut, "%-*s %d\n", colWidth, candidateNames[i], candidateVotes[i]);
        if (candidateVotes[i] > maxVotes) {
            maxVotes = candidateVotes[i];
        }
    }

    // 5. Afficher les gagnants
    fprintf(fileOut, "Les gagnants:\n");
    for (int i = 0; i < numOfCandidates; i++) {
        if (candidateVotes[i] == maxVotes) {
            fprintf(fileOut, "%s\n", candidateNames[i]);
        }
    }

    fclose(fileOut);
    return EXIT_SUCCESS;
}
