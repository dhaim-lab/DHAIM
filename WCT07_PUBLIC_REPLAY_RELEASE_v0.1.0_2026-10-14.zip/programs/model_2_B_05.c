#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CANDIDATES 50
#define MAX_NAME_LEN   100

int main(void)
{
    FILE *fileIn, *fileOut;
    char candidateNames[MAX_CANDIDATES][MAX_NAME_LEN];
    int  candidateVotes[MAX_CANDIDATES] = {0};
    int  numOfCandidates = 0;
    int  totalVotes = 0, invalidVotes = 0, maxVotes = 0;
    int  vote, i, len, maxNameWidth = 0;

    /* ---------- Ouverture du fichier d'entree ---------- */
    fileIn = fopen("votes.txt", "r");
    if (fileIn == NULL) {
        perror("Erreur lors de l'ouverture du fichier votes.txt");
        return EXIT_FAILURE;
    }

    /* ---------- Lecture des noms des candidats ----------
       Un nom est une ligne qui ne commence pas par un chiffre. */
    while (numOfCandidates < MAX_CANDIDATES &&
           fgets(candidateNames[numOfCandidates], MAX_NAME_LEN, fileIn) != NULL)
    {
        /* suppression du '\n' et d'un eventuel '\r' (fichiers Windows) */
        candidateNames[numOfCandidates][strcspn(candidateNames[numOfCandidates], "\r\n")] = '\0';

        /* ligne vide -> on l'ignore */
        if (candidateNames[numOfCandidates][0] == '\0')
            continue;

        /* si la ligne commence par un chiffre, ce sont les votes :
           on revient en arriere et on sort de la boucle               */
        if (candidateNames[numOfCandidates][0] >= '0' &&
            candidateNames[numOfCandidates][0] <= '9')
        {
            /* on "rejoue" cette ligne pour la lecture des votes */
            fseek(fileIn, -(long)strlen(candidateNames[numOfCandidates]) - 1, SEEK_CUR);
            break;
        }

        /* largeur maximale des noms (pour l'alignement) */
        len = (int)strlen(candidateNames[numOfCandidates]);
        if (len > maxNameWidth)
            maxNameWidth = len;

        numOfCandidates++;
    }

    if (numOfCandidates == 0) {
        fprintf(stderr, "Aucun candidat trouve dans votes.txt\n");
        fclose(fileIn);
        return EXIT_FAILURE;
    }

    /* ---------- Ouverture du fichier de sortie ---------- */
    fileOut = fopen("resultats.txt", "w");
    if (fileOut == NULL) {
        perror("Erreur lors de l'ouverture du fichier resultats.txt");
        fclose(fileIn);
        return EXIT_FAILURE;
    }

    /* ---------- Lecture et depouillement des votes ---------- */
    while (fscanf(fileIn, "%d", &vote) == 1) {
        totalVotes++;
        if (vote >= 1 && vote <= numOfCandidates) {
            candidateVotes[vote - 1]++;
        } else {
            invalidVotes++;
            fprintf(fileOut, "Vote invalide : %d\n", vote);
        }
    }
    fclose(fileIn);

    /* ---------- Score maximum ---------- */
    for (i = 0; i < numOfCandidates; i++)
        if (candidateVotes[i] > maxVotes)
            maxVotes = candidateVotes[i];

    /* ---------- Resultats ---------- */
    fprintf(fileOut, "Nombre d'electeurs : %d\n", totalVotes);
    fprintf(fileOut, "Nombre de votes valides : %d\n", totalVotes - invalidVotes);
    fprintf(fileOut, "Nombre de votes annules : %d\n", invalidVotes);

    fprintf(fileOut, "%-*s  %s\n", maxNameWidth, "Candidat", "score");
    for (i = 0; i < numOfCandidates; i++)
        fprintf(fileOut, "%-*s  %5d\n", maxNameWidth, candidateNames[i], candidateVotes[i]);

    /* ---------- Gagnant(s) ---------- */
    fprintf(fileOut, "Les gagnants:\n");
    for (i = 0; i < numOfCandidates; i++)
        if (candidateVotes[i] == maxVotes)
            fprintf(fileOut, "%s\n", candidateNames[i]);

    fclose(fileOut);

    printf("Traitement termine : voir le fichier resultats.txt\n");
    return EXIT_SUCCESS;
}
