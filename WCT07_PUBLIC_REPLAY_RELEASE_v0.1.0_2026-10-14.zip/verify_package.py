from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256_MANIFEST.json'}
assert actual==set(manifest), 'Missing or extra files'
for name,digest in manifest.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest, name
index=json.loads((root/'program_index.json').read_text(encoding='utf-8'))
assert len(index)==45 and len({r['run_id'] for r in index})==45
for row in index:
    assert hashlib.sha256((root/row['program']).read_bytes()).hexdigest()==row['program_sha256']
print('HASH AND COMPLETENESS PASS: 45 unchanged programs')
